﻿
uses CRT; 

Type NodePtr = ^Node;
  Node = record
    Name: char; 
    Left, Right: NodePtr;
  end; 
  
Var Top: NodePtr; 

procedure MakeSubTrees(Var Leaf: NodePtr); 
Var Top: NodePtr;
    key: char; 
begin
  GoToXY(30, 18); writeln('Введите текущий узел');
  GoToXY(40, 19); readln(Leaf^.Name); 
  GoToXY(30, 18); ClearLine; 
  GoToXY(40, 19); ClearLine; 
  
  // левое поддерево
  GoToXY(25, 20); writeln(Leaf^.Name, ' имеет левое поддерево?:');
  GoToXY(40, 21); readln(key); 
  GoToXY(25, 20); ClearLine; 
  GoToXY(40, 21); ClearLine; 
  
  if key in ['y', 'Y', 'н', 'Н'] then 
  begin
    new(Top); 
    Leaf^.Left:=Top; 
    MakeSubTrees(Top); 
  end
  else Leaf^.Left:= Nil; 
  
  // правое поддерево 
  GoToXY(25, 20); writeln(Leaf^.Name, ' имеет правое поддерево?:');
  GoToXY(40, 21); readln(key); 
  GoToXY(25, 20); ClearLine; 
  GoToXY(40, 21); ClearLine; 
  
  if key in ['y', 'Y', 'н', 'Н'] then 
  begin
    new(Top); 
    Leaf^.Right:=Top; 
    MakeSubTrees(Top); 
  end
  else Leaf^.Right:= Nil; 
  
end;

procedure MakeTree(Var Top: NodePtr); 
begin
  new(Top); 
  MakeSubTrees(Top); 
end;

procedure WayUpDownDynamic(Top: NodePtr); 
begin
  if Top<>Nil then 
  begin
    write(Top^.Name, ' '); 
    WayUpDownDynamic(Top^.Left);
    WayUpDownDynamic(Top^.Right);
  end;
end;

procedure WayDownUpDynamic(Top: NodePtr);
begin
  if Top<>Nil then 
  begin
    WayDownUpDynamic(Top^.Left); 
    WayDownUpDynamic(Top^.Right);
    write(Top^.Name, ' '); 
  end;
end; 

procedure WayHoriz(Top: NodePtr; Level: byte);
begin
  if Top<>Nil then 
    if Level = 1 then write(Top^.Name, ' ')
    else 
    begin
      WayHoriz(Top^.Left, Level - 1); 
      WayHoriz(Top^.Right, Level - 1); 
    end;
end; 

function High(Top: NodePtr): byte; 
Var HighLeft, HighRight: byte; 
begin
  if Top<>Nil then High:=0
  else 
  begin
    HighLeft:=High(Top^.Left); 
    HighRight:=High(Top^.Right);
    
    if HighLeft >HighRight then 
      High:=HighLeft + 1 else High:=HighRight + 1;  
  end;
end; 

procedure ViewTree(Top: NodePtr); 
Var HighTree:byte; 
begin
  HighTree:=High(Top); 
  for var i:=1 to HighTree do 
  begin
    writeln; WayHoriz(Top, i); 
  end;
end;

procedure SearchNode(Top: NodePtr; Var Leaf: NodePtr); 
Var Ok: boolean;
    Symbol: char; 
begin
  if (Top<>Nil) and (Ok=True) then
  begin
    if Symbol = Top^.Name then 
    begin
      Ok:=False; Leaf:=Top
    end
    else 
    begin
      SearchNode(Top^.Left, Leaf); 
      SearchNode(Top^.Right, Leaf); 
    end;
   end;
end;

procedure AddSubTree(Top: NodePtr); 
Var Symbol: char; 
    Key: char; 
begin
  GoToXY(30, 18); writeln('Введите искомый узел'); 
  GoToXY(40, 19); readln(Symbol); 
  Ok:=True; SearchNode(Top, Leaf); 
  
  if Ok = True then
    writeln('Узел ', Symbol, ' не найден')
  else 
  begin
    GoToXY(23, 20); 
    writeln('Желаете построить левое поддерево у ', Leaf.Name, ' ?'); 
    GoToXY(40, 21); readln(Key); 
    GoToXY(40, 21); ClearLine; 
    
    // левое поддерево
    if Key in ['y', 'Y', 'н', 'Н'] then 
      if Leaf^.Left <> Nil then 
      begin
        GoToXY(25, 19); 
        writeln('Левое поддерево у ', Leaf^.Name, ' уже есть!'); 
        GoToXY(26, 19); writeln('Все-таки желаете?'); 
        GoToXY(40, 21); readln(Key); 
        GoToXY(40, 21); clearLine;
        
        if Key in ['y', 'Y', 'н', 'Н'] then 
        begin
          MakeTree(Top); Leaf^.Left:=Top; 
        end;
      end 
      else 
      begin
        MakeTree(Top); Leaf^.Left:=Top; 
      end;
      
      // правое поддерево
      if Key in ['y', 'Y', 'н', 'Н'] then 
      if Leaf^.Right <> Nil then 
      begin
        GoToXY(25, 19); 
        writeln('Правое поддерево у ', Leaf^.Name, ' уже есть!'); 
        GoToXY(26, 19); writeln('Все-таки желаете?'); 
        GoToXY(40, 21); readln(Key); 
        GoToXY(40, 21); clearLine;
        
        if Key in ['y', 'Y', 'н', 'Н'] then 
        begin
          MakeTree(Top); Leaf^.Right:=Top; 
        end;
      end 
      else 
      begin
        MakeTree(Top); Leaf^.Right:=Top; 
      end;
  end;
end;

