﻿Unit QQueu;

Interface

Uses CRT, SStack;

Type
  PtrQ = ^Queu;
  Queu = record
    Inf: integer;
    Next: PtrQ;
  end;

procedure MakeQueu(var Left, Right: PtrQ);
procedure AddQueu(var Right: PtrQ);
procedure ViewQueu(Left: PtrQ);
procedure FusionQueu(Left1, Left2: PtrQ);
procedure StackFromQueu(Left: PtrQ; var Top: Ptr);
procedure MenuQueu;   // <-- объявление меню

Implementation

procedure Wait;
begin
  repeat until KeyPressed;
  while KeyPressed do ReadKey;
end;

procedure MakeQueu(var Left, Right: PtrQ);
var
  Ok: boolean;
  value: integer;
  Top: PtrQ;
begin
  Ok := true;
  Left := nil;
  Right := nil;
  writeln('Введите число (999 - завершить ввод):');
  readln(value);
  if value = 999 then
    Ok := false
  else
  begin
    New(Top);
    Top^.inf := value;
    Top^.Next := nil;
    Left := Top;
    Right := Top;
  end;

  while Ok do
  begin
    writeln('Введите число (999 - завершить):');
    readln(value);
    if value = 999 then
      Ok := false
    else
    begin
      New(Top);
      Top^.inf := value;
      Top^.Next := nil;
      Right^.Next := Top;
      Right := Top;
    end;
  end;
end;

procedure AddQueu(var Right: PtrQ);
var
  Ok: boolean;
  value: integer;
  Top: PtrQ;
begin
  Ok := true;
  while Ok do
  begin
    writeln('Введите число для добавления (999 - выход):');
    readln(value);
    if value = 999 then
      Ok := false
    else
    begin
      New(Top);
      Top^.inf := value;
      Top^.Next := nil;
      Right^.Next := Top;
      Right := Top;
    end;
  end;
end;

procedure ViewQueu(Left: PtrQ);
var
  Top: PtrQ;
begin
  Top := Left;
  while Top <> nil do
  begin
    write(Top^.inf:4);
    Top := Top^.Next;
  end;
  writeln;
end;

procedure FusionQueu(Left1, Left2: PtrQ);
var
  Top: PtrQ;
begin
  if Left1 = nil then Exit;
  Top := Left1;
  while Top^.Next <> nil do
    Top := Top^.Next;
  Top^.Next := Left2;
end;

procedure StackFromQueu(Left: PtrQ; var Top: Ptr);
var
  Topq: PtrQ;
  Kon: Ptr;
begin
  Top := nil;
  Topq := Left;
  while Topq <> nil do
  begin
    New(Kon);
    Kon^.Next := Top;
    Kon^.inf := Topq^.inf;
    Top := Kon;
    Topq := Topq^.Next;
  end;
end;

{----------------- Меню для работы с очередями -----------------}
procedure MenuQueu;
var
  Mode: integer;
  Left1, Right1, Left2, Right2: PtrQ;
  StackTop: Ptr;
  Ok: boolean;
begin
  Left1 := nil; Right1 := nil;
  Left2 := nil; Right2 := nil;
  StackTop := nil;
  Ok := true;

  while Ok do
  begin
    ClrScr;
    writeln('========== ОЧЕРЕДИ ==========');
    writeln('1) Создать первую очередь');
    writeln('2) Добавить элемент в первую очередь');
    writeln('3) Просмотреть первую очередь');
    writeln('4) Создать вторую очередь');
    writeln('5) Добавить элемент во вторую очередь');
    writeln('6) Просмотреть вторую очередь');
    writeln('7) Слить две очереди (первая + вторая)');
    writeln('8) Преобразовать первую очередь в стек');
    writeln('9) Просмотреть полученный стек');
    writeln('0) Назад');
    writeln('================================');
    write('Выберите действие: ');
    readln(Mode);

    case Mode of
      1:
      begin
        ClrScr;
        writeln('=== СОЗДАНИЕ ПЕРВОЙ ОЧЕРЕДИ ===');
        MakeQueu(Left1, Right1);
        writeln('Очередь создана.');
        Wait;
      end;
      2:
      begin
        ClrScr;
        if Left1 = nil then
          writeln('Сначала создайте очередь (пункт 1)')
        else
        begin
          writeln('=== ДОБАВЛЕНИЕ В ПЕРВУЮ ОЧЕРЕДЬ ===');
          AddQueu(Right1);
        end;
        Wait;
      end;
      3:
      begin
        ClrScr;
        if Left1 = nil then
          writeln('Очередь пуста.')
        else
          ViewQueu(Left1);
        Wait;
      end;
      4:
      begin
        ClrScr;
        writeln('=== СОЗДАНИЕ ВТОРОЙ ОЧЕРЕДИ ===');
        MakeQueu(Left2, Right2);
        writeln('Вторая очередь создана.');
        Wait;
      end;
      5:
      begin
        ClrScr;
        if Left2 = nil then
          writeln('Сначала создайте вторую очередь (пункт 4)')
        else
        begin
          writeln('=== ДОБАВЛЕНИЕ ВО ВТОРУЮ ОЧЕРЕДЬ ===');
          AddQueu(Right2);
        end;
        Wait;
      end;
      6:
      begin
        ClrScr;
        if Left2 = nil then
          writeln('Вторая очередь пуста.')
        else
          ViewQueu(Left2);
        Wait;
      end;
      7:
      begin
        ClrScr;
        if (Left1 = nil) or (Left2 = nil) then
          writeln('Одна из очередей пуста, слияние невозможно.')
        else
        begin
          FusionQueu(Left1, Left2);
          writeln('Очереди слиты. Результат в первой очереди.');
          Left2 := nil; Right2 := nil; // очищаем указатели, чтобы не было дублирования
        end;
        Wait;
      end;
      8:
      begin
        ClrScr;
        if Left1 = nil then
          writeln('Первая очередь пуста.')
        else
        begin
          StackFromQueu(Left1, StackTop);
          writeln('Стек создан из первой очереди.');
        end;
        Wait;
      end;
      9:
      begin
        ClrScr;
        if StackTop = nil then
          writeln('Стек пуст (сначала выполните пункт 8).')
        else
        begin
          writeln('Содержимое стека:');
          ViewStack(StackTop);  // процедура из SStack
        end;
        Wait;
      end;
      0: Ok := false;
      else
        writeln('Неверный выбор.');
        Wait;
    end;
  end;
end;

end.