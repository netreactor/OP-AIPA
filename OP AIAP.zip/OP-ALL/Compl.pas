﻿Unit Compl;
Interface
uses crt;
Type Complex = record
  Re, Im: real;
end;

Const eps = 0.001; 
var u,v,w,z: Complex; var q: real;

procedure Add(u,v: Complex; var w: Complex);
procedure Mult(u,v: Complex; var w: Complex);
procedure Inv(u: Complex; var w: Complex);
procedure Divz(u,v: Complex; var w: Complex);
procedure Codj(z: Complex; var w: Complex);
procedure Prod(a: real; z: Complex; var w: Complex);
procedure Zero(var z: Complex);
procedure One(var z: Complex);
function Module(z: Complex): real;
procedure ExpC(z: Complex; var w: Complex);
procedure CosC(z: Complex; var w: Complex);
procedure SinC(z: Complex; var w: Complex);

procedure Input(var z:Complex);
procedure Output(x,y: integer; z: Complex);
procedure OutputC(x,y: integer; z: Complex);
procedure wait;
procedure menuComplex;

Implementation

procedure Add(u, v:Complex; var w:Complex);
begin
  w.Re := u.Re + v.Re;
  w.Im := u.Im + v.Im;
end;

procedure Mult(u, v:Complex; var w:Complex);
begin
  w.Re := u.Re * v.Re - u.Im * v.Im;
  w.Im := u.Re * v.Im + u.Im * v.Re;
end;

procedure Inv(u:Complex; var w: Complex);
var zn: real;
begin
  zn := sqr(u.Re) + sqr(u.Im);
  w.Re := u.Re/zn;
  w.Im := -u.Im/zn;
end;

procedure Divz(u, v:Complex; var w:Complex);
var z:Complex;
begin
  inv(v,z);
  mult(u,z,w);
end;

function Module(z:Complex):real;
begin
  module := sqrt(sqr(z.Re) + sqr(z.Im));
end;

procedure Codj(z:Complex; var w:Complex);
begin
  w.Re := z.Re;
  w.Im := -z.Im;
end;

procedure Zero(var z:Complex);
begin
  z.Re := 0;
  z.Im := 0;
end;

procedure Prod(a:real; z:Complex; var w:Complex);
begin
  w.Re := a*z.Re;
  w.Im := a*z.Im;
end;

procedure One(var z:Complex);
begin
  z.Re := 1;
  z.Im := 0;
end;

procedure ExpC(z:Complex; var w: Complex);
var 
  k:integer; 
  p:Complex; 
  m:real;
begin
  One(p); 
  One(w); 
  k := 0;
  while Module(p) >= eps do
  begin
    k:= k + 1;
    m:= 1/k;
    Mult(p,z,p);
    Prod(m,p,p);
    Add(w,p,w);
  end;
end;

procedure SinC(z: Complex; var w: Complex);
var 
  k: integer; 
  u,p,v: Complex;
begin
  k:= 0; 
  Zero(v); 
  One(p); 
  Add(v,w,w); 
  Mult(z,z,u);
  while Module(p) >= eps do  
  begin
    k:= k + 2; 
    Mult(p,u,p);
    Prod(-1/(k*(k+1)),p,p); 
    Add(w,p,w);
  end;
end;

procedure Input(var z: Complex);
begin
  writeln('Введите действительную часть комплексного числа:');
  readln(z.Re);
  writeln(' ');
  writeln('Введите мнимую часть комплексного числа:');
  read(z.Im);
end;

procedure CosC( z: Complex; var w: Complex);
var k: integer; u,p: Complex;
begin
  k:= 0; One(p); One(w); Mult(z,z,u);
  while Module(p) >= eps do
  begin
    k:= k + 2; Mult(p,u,p);
    Prod(-1/k/(k-1),p,p);
    Add(w,p,w);
  end;
end;

procedure Output(x,y: integer; z: Complex);
var k:integer; i:real;
begin
  GoTOXY(y,x); write('('); writeln(z.Re);
  i:= z.Re;
  k:= 0;
  while i > 0 do
  begin
    i:= int(i/10);
    k:= k + 1;
  end;
  GoTOXY(y+4+k,x); write(z.Im); writeln('i)')
end;

procedure OutputC(x,y: integer; z: Complex);
var k:integer; i:real;
begin
  GoTOXY(y,x); write('('); writeln(z.Re);
  GoTOXY(y,x+1); write(z.Im); writeln('i)')
end;

procedure wait;
begin
  repeat until KeyPressed;
end;

procedure menuComplex;
var Ok: boolean; mode: integer; 
u,v,w: complex; a:real;
begin
  Ok:= true;
  while Ok do
  begin
    ClrScr;
    writeln('укажите режим работы');
    writeln('1: Сложение комплексных чисел');
    writeln('2: Умножение комплексных чисел');
    writeln('3: Инверсия комплексного числа');
    writeln('4: Деление комплексных чисел');
    writeln('5: Модуль комплексного числа');
    writeln('6: Сопряженое комплексного числа');
    writeln('7: комплексная еденица');
    writeln('8: комплексный ноль');
    writeln('9: Умножение комплексного числа на число');
    writeln('10: Экспанента комплексного числа');
    writeln('11: Комплесный косинус');
    writeln('12: Комплесный синус');
    writeln('0 open the door');
    GoToXY(40, 23); readln(mode);
    GoToXY(40,23); ClearLine;
    case mode of
      1: begin
        input(u); input(v);
        add(u,v,w); output(7,40,w);
        wait;
      end;
      2: begin
        input(u); input(v);
        mult(u,v,w); output(7,40,w);
        wait;
      end;
      3: begin
        input(u);
        inv(u,w); output(7,40,w);
        wait;
      end;
      4: begin
        input(u); input(v);
        divz(u,v,w); output(7,40,w);
        wait;
      end;
      5: begin
        input(u);
        GoToXY(8,50);
        writeln(module(u));
        wait;
      end;
      6: begin
        input(u);
        codj(u,w); output(7,40,w);
        wait;
      end;
      7: begin
        one(u);
        output(7,40,u);
        wait;
      end;
      8: begin
        zero(u);
        output(7,40,u);
        wait;
      end;
      9: begin
        readln(a); input(u);
        prod(a,u,w); output(7,40,w);
        wait;
      end;
      10: begin
        input(u);
        expC(u,w); outputC(7,40,w);
        wait;
      end;
      11: begin
        input(u);
        cosC(u,w); outputC(7,40,w);
        wait;
      end;
      12: begin
        input(u);
        sinC(u,w); outputC(7,40,w);
        wait;
      end;
      0: begin
        Ok:= false;
      end;
      else begin
        GoToXY(30,23);
        writeln('ошибка, повторите ввод');
        wait;
      end;
    end;
  end;
end;

End. 