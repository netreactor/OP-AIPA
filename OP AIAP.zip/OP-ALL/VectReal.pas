﻿Unit VectReal;

interface

Uses crt; 

const n = 3;

Type 
  Vector = array[1..n] of real;

var 
  u, v, w: Vector;
  h: real;

procedure AddVector(u, v: Vector; var w: Vector);
function ScalProd(u, v: Vector): real;
procedure VectProd(u, v: Vector; var w: Vector);
function MixProd(u, v, w: Vector): real;
function LengthVec(u: Vector): real; 

procedure InputVect1(var x: Vector);
procedure InputVect(var x, y: Vector);
procedure InputThreeVectors(var x, y, t: Vector);
procedure OutputVect(var t: Vector);
procedure Wait;
procedure MenuRVect();

implementation

procedure AddVector(u, v: Vector; var w: Vector);
Var i: integer; 
begin 
  for i := 1 to n do 
    w[i] := u[i] + v[i]; 
end;

function ScalProd(u, v: Vector): real; 
Var i: integer; 
    C: real; 
begin
  C:= 0; 
  for i := 1 to n do C := C + u[i] * v[i]; 
  ScalProd := C; 
end; 

procedure VectProd(u, v: Vector; Var w: Vector); 
begin
  w[1] := u[2] * v[3] - u[3] * v[2]; 
  w[2] := u[3] * v[1] - u[1]  * v[3];
  w[3] := u[1] * v[2] - u[2] * v[1];
end;

function MixProd(u, v, w: Vector): real; 
Var z: Vector; 
begin
  VectProd(v, w, z); 
  MixProd := ScalProd(u, z); 
end;

function LengthVec(u: Vector): real; 
begin
  LengthVec := sqrt(ScalProd(u, u)); 
end;

procedure InputVect1(var x: Vector);
var 
  i: integer;
begin
  Writeln('Введите элементы вектора:');
  writeln(' ');
  for i := 1 to n do
  begin
    GoToXY(5 * i + 10, 3);
    readln(x[i]);
  end;
end;

procedure InputVect(var x, y: Vector);
var 
  i: integer;
begin
  Writeln('Введите элементы первого вектора вектора:');
  for i := 1 to n do
  begin
    GoToXY(5 * i + 9, 3);
    readln(x[i]);
  end;
  Writeln(' ');
  Writeln('Введите элементы второго вектора вектора:');
  for i := 1 to n do
  begin
    GoToXY(5 * i + 9, 7);
    readln(y[i]);
  end;
end;

procedure InputThreeVectors(var x, y, t: Vector);
var
  i: integer;
begin
  ClrScr;
  Writeln('Введите элементы первого вектора:');
  for i := 1 to n do
  begin
    GoToXY(5 * i + 9, 3);  // Первая строка
    readln(x[i]);
  end;

writeln(' ');
  Writeln('Введите элементы второго вектора:');
  for i := 1 to n do
  begin
    GoToXY(5 * i + 9, 7);  // Вторая строка
    readln(y[i]);
  end;

writeln(' ');
  Writeln('Введите элементы третьего вектора:');
  for i := 1 to n do
  begin
    GoToXY(5 * i + 9, 11);  // Третья строка
    readln(t[i]);
  end;
end;

procedure OutputVect(var t: Vector);
var 
  i: integer;
begin
  Writeln(' ');
  Writeln('Результат:');
  for i := 1 to n do
  begin
    GoToXY(5 * i + 9, 10);
    writeln(t[i]);
  end;
end;

procedure Wait;
begin
  repeat until KeyPressed;
  while KeyPressed do ReadKey;
end;

procedure MenuRVect();
var 
  Mode: integer;
  Ok: boolean;
  x, y, t, w: Vector;
  h: real;
begin
  Ok := true;
  while Ok do
  begin
    ClrScr;
    writeln('Укажите режим:');
    writeln('1) Сложение векторов');
    writeln('2) Скалярное произведение');
    writeln('3) Векторное произведение');
    writeln('4) Смешанное произведение');
    writeln('5) Модуль вектора');
    writeln('0) Выход');
    
    GoToXY(1, 10); 
    read(Mode);
    GoToXY(1, 10); 
    ClearLine;
    
    case Mode of
      1: 
      begin
          ClrScr;
          InputVect(x, y);
          AddVector(x, y, t);
          OutputVect(t);
          Wait;
      end;
      2:
      begin
        ClrScr;
        InputVect(x, y);
        h := ScalProd(x, y);
        writeln(' ');
        writeln('Результат:');
        write(h);
        Wait;
      end;
      3:
      begin
        ClrScr;
        InputVect(x, y);
        VectProd(x, y, t);
        OutputVect(t);
        Wait;
      end;
      4:
      begin
        ClrScr;
        InputThreeVectors(x, y, t);
        h := MixProd(x, y, t);
        writeln(' ');
        writeln('Результат:');
        write(h);
        Wait;
      end;
      5:
      begin
        ClrScr;
        InputVect1(x);
        h := LengthVec(x);
        GoToXY(1, 4);
        Writeln(' ');
        Writeln('Результат:');
        write(h:0:1);
        Wait;
      end;
      0: 
        Ok := false;
      else
      begin
        GoToXY(30, 21);
        writeln('Ошибка. повторите ввод');
        sleep(1000);
      end;
    end;
  end;
end;

end.