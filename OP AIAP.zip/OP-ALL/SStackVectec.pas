﻿Uses Crt, SStack;

Type PtrVertec = ^StakVertec;
StakVertec = record
  NumberV: integer;
  Score: integer;
  Name: String[10];
  NextV: PtrVertec;
end;

PtrHoriz = ^StakHoriz;
StakHoriz = record
  NumberH: integer;
  Group: String[6];
  Head: PtrVertec;
  NextH: PtrHoriz;
end;

var Horiz: PtrHoriz;

procedure InvertVertecStack(Top1: PtrVertec; var Top2: PtrVertec);
var Kon1, Kon2: PtrVertec;
begin
  Top2 := Nil;
  Kon1 := Top1;
  while Kon1 <> Nil do
  begin
    New(Kon2); Kon2^.NextV := Top2;
    Kon2^.NumberV := Kon1^.NumberV;
    Kon2^.Score := Kon1^.Score;
    Kon2^.Name := Kon1^.Name;
    Top2 := Kon2;
    Kon1 := Kon1^.NextV;
  end;
end;

procedure InvertHorizStack(Top1: PtrHoriz; var Top2: PtrHoriz);
var Kon1, Kon2: PtrHoriz;
begin
  Top2 := Nil;
  Kon1 := Top1;
  while Kon1 <> Nil do
  begin
    New(Kon2); Kon2^.NextH := Top2;
    Kon2^.NumberH := Kon1^.NumberH;
    Kon2^.Group := Kon1^.Group;
    Kon2^.Head := Kon1^.Head;
    Top2 := Kon2;
    Kon1 := Kon1^.NextH;
  end;
end;

procedure MakeMenuVertec(var Vertec: PtrVertec);
var Top: PtrVertec;
Ok: boolean;
NameValue: String[10];
k,n: integer;
begin
  Ok := true;
  Vertec := Nil; K := 0;
  while Ok do
  begin
    writeln ('введите фамилию');
    readln (NameValue);
    if (NameValue = 'n') then
    begin
      Ok := false;
    end
    else begin
    writeln('введите оценку');
    readln(n);
    New(Top); Top^.NextV := Vertec;
    Top^.NumberV := k; Top^.Name := NameValue; Top^.Score := n;
    Vertec := Top;
    end;
  end;
end;

procedure MakeMenuVertecInvert(var Vertec: PtrVertec);
var Top: PtrVertec;
Ok: boolean;
NameValue: String[10];
k,n: integer;
begin
  Ok := true;
  Vertec := Nil; K := 0;
  while Ok do
  begin
    writeln ('введите фамилию');
    readln (NameValue);
    if (NameValue = 'n') then
    begin
      InvertVertecStack(Vertec,Vertec);
      Ok := false;
    end
    else begin
    writeln('введите оценку');
    readln(n);
    New(Top); Top^.NextV := Vertec;
    Top^.NumberV := k; Top^.Name := NameValue; Top^.Score := n;
    Vertec := Top;
    end;
  end;
end;

procedure MakeMenuHoriz;
var Vertec: PtrVertec;
Top: PtrHoriz;
GroupValue: string[10];
Ok: boolean;
k:integer;
begin
  Ok := true; Horiz := Nil; k:= 0;
  while Ok do
  begin
    writeln ('Введите название группы');
    readln(GroupValue); k:= k + 1;
    if (GroupValue = 'n') then Ok := false
    else begin
      New(Top); Top^.NextH := Horiz;
      Top^.NumberH := k; Top^.Group := GroupValue;
      MakeMenuVertec(Vertec);
      Top^.Head := Vertec;
      Horiz := Top;
    end;
  end;
end;

procedure MakeMenuHorizInvert;
var Vertec: PtrVertec;
Top: PtrHoriz;
GroupValue: string[10];
Ok: boolean;
k:integer;
begin
  Ok := true; Horiz := Nil; k:= 0;
  while Ok do
  begin
    writeln ('Введите название группы');
    readln(GroupValue); k:= k + 1;
    if (GroupValue = 'n') then 
    begin
      InvertHorizStack(Horiz,Horiz);
      Ok := false;
    end
    else begin
      New(Top); Top^.NextH := Horiz;
      Top^.NumberH := k; Top^.Group := GroupValue;
      MakeMenuVertecInvert(Vertec);
      Top^.Head := Vertec;
      Horiz := Top;
    end;
  end;
end;

procedure PutMenuVertec(Vertec: PtrVertec; n:integer);
var Top: PtrVertec;
PosX,PosY: integer;
begin
  Top:= Vertec; PosY := 2;
  PosX := 12*n - 7;
  while Top <> Nil do
  begin
    PosY := PosY + 1;
    GoToXY(PosX,PosY);
    write(Top^.Name); write('/',Top^.Score);
    Top := Top^.NextV;
  end;
end;

procedure PutMenuVertecA(Vertec: PtrVertec; n:integer);
var Top: PtrVertec;
PosX,PosY: integer;
begin
  Top:= Vertec; PosY := 2;
  PosX := 12*n - 7;
  while Top <> Nil do
  begin
    if Top^.Score = 5 then
    begin
      PosY := PosY + 1;
      GoToXY(PosX,PosY);
      write(Top^.Name); write('/',Top^.Score);
    end;
    Top := Top^.NextV;
  end;
end;

procedure ChoiceMenuHoriz;
var Top: PtrHoriz; n,k: integer;
begin
  Top := Horiz; n := 0;
  while Top <> Nil do
  begin
    n := n + 1;
    write(n:5,'.',Top^.Group:6);
    Top := Top^.NextH;
  end;
  GoToXY(30,20); writeln('Выберите пук меню');
  goToXY(32,22); read(n);
  Top:= Horiz; k:= Horiz^.NumberH + 1;
  while (Top^.NumberH + n <> k) do
    Top := Top^.NextH;
  PutMenuVertec(Top^.Head,n);
end;

procedure ChoiceMenuHorizA;
var Top: PtrHoriz; n,k: integer;
begin
  Top := Horiz; n := 0;
  while Top <> Nil do
  begin
    n := n + 1;
    write(n:5,'.',Top^.Group:6);
    Top := Top^.NextH;
  end;
  GoToXY(30,20); writeln('Выберите пук меню');
  goToXY(32,22); read(n);
  Top:= Horiz; k:= Horiz^.NumberH + 1;
  while (Top^.NumberH + n <> k) do
    Top := Top^.NextH;
  PutMenuVertecA(Top^.Head,n);
end;

procedure ChoiceMenuHorizInvert;
var Top: PtrHoriz; n,k: integer;
begin
  Top := Horiz; n := 0;
  while Top <> Nil do
  begin
    n := n + 1;
    write(n:5,'.',Top^.Group:6);
    Top := Top^.NextH;
  end;
  GoToXY(30,20); writeln('Выберите пук меню');
  goToXY(32,22); read(n);
  Top:= Horiz;
  while (Top^.NumberH <> n) do
    Top := Top^.NextH;
  PutMenuVertec(Top^.Head,n);
end;

procedure ChoiceMenuHorizInvertA;
var Top: PtrHoriz; n,k: integer;
begin
  Top := Horiz; n := 0;
  while Top <> Nil do
  begin
    n := n + 1;
    write(n:5,'.',Top^.Group:6);
    Top := Top^.NextH;
  end;
  GoToXY(30,20); writeln('Выберите пук меню');
  goToXY(32,22); read(n);
  Top:= Horiz;
  while (Top^.NumberH <> n) do
    Top := Top^.NextH;
  PutMenuVertecA(Top^.Head,n);
end;

begin
  MakeMenuHoriz;
  ClrScr;
  ChoiceMenuHorizA;
end.