﻿unit Tree;

interface

uses CRT;

const
  n = 11;

type
  Node = record
    ch: Char;
    left, right: Byte;
  end;

var
  TreeArr: array[1..n] of Node;
  Root: Byte;

procedure RunTreeLab;

implementation

var
  FileName: Text;

procedure LoadTree;
var
  i: Integer;
begin
  Assign(FileName,
    'C:\Users\stud\Desktop\Pascal\библиотеки 2 семестр\tree.txt.txt');

  Reset(FileName);

  for i := 1 to n do
    with TreeArr[i] do
      ReadLn(FileName, ch, left, right);

  ReadLn(FileName, Root);

  Close(FileName);
end;

procedure WayUpDown(Next: Byte);
begin
  if Next <> 0 then
    with TreeArr[Next] do
    begin
      Write(ch, ' ');
      WayUpDown(left);
      WayUpDown(right);
    end;
end;

procedure WayDownUp(Next: Byte);
begin
  if Next <> 0 then
    with TreeArr[Next] do
    begin
      WayDownUp(left);
      WayDownUp(right);
      Write(ch, ' ');
    end;
end;

procedure ShowArray;
var
  i: Integer;
begin
  Writeln;
  Writeln('№   Символ   Левый   Правый');
  Writeln('---------------------------');

  for i := 1 to n do
    Writeln(
      i:2, '     ',
      TreeArr[i].ch, '       ',
      TreeArr[i].left:2, '      ',
      TreeArr[i].right:2
    );
end;

procedure RunTreeLab;
var
  Choice: Integer;
begin

  LoadTree;

  repeat
    ClrScr;

    Writeln('====================');
    Writeln(' ЛР 5 - ДЕРЕВО ИЗ ФАЙЛА');
    Writeln('====================');
    Writeln('1 - Прямой обход');
    Writeln('2 - Обратный обход');
    Writeln('3 - Показать массив');
    Writeln('4 - Показать корень');
    Writeln('0 - Назад');
    Writeln('====================');

    Write('Выберите пункт: ');
    ReadLn(Choice);

    case Choice of

      1:
      begin
        ClrScr;
        Writeln('Прямой обход дерева:');
        WayUpDown(Root);
        Writeln;
        ReadLn;
      end;

      2:
      begin
        ClrScr;
        Writeln('Обратный обход дерева:');
        WayDownUp(Root);
        Writeln;
        ReadLn;
      end;

      3:
      begin
        ClrScr;
        ShowArray;
        ReadLn;
      end;

      4:
      begin
        ClrScr;
        Writeln('Корень дерева: ', TreeArr[Root].ch);
        Writeln('Номер корня: ', Root);
        ReadLn;
      end;

    end;

  until Choice = 0;
end;

end.