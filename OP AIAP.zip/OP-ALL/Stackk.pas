﻿Unit INTStack; 

Interface 

Type Ptr = ^Stak; 
Stak = record 
  Inf: integer; 
  Next: Ptr;  
end;

Var Top, Kon, Top1, Top2: Ptr; 
    MergeStack: Ptr; 
    Value: integer; 

procedure MakeStack(Var Top: Ptr); 
procedure AddStack(Var Top: Ptr); 
procedure ViewStack(Top: Ptr); 
procedure DeleteTop(Var Top: Ptr);
procedure ReversedStack(Top: Ptr); 
procedure DeleteStack(Top: Ptr); 

Implementation 

procedure MakeStack(Var Top: Ptr); 
Var Ok: boolean; 
begin
  Ok := True; 
  Top := Nil; 
  while Ok do 
  begin
    writeln('Введите число:'); 
    readln(Value); 
    if (Value = 999) then Ok := False
    else 
    begin
      New(Kon); 
      Kon^.Next := Top; 
      Kon^.Inf := Value; 
      Top := Kon; 
    end;
  end;
end;

procedure AddStack(Var Top: Ptr); 
Var Ok: boolean; 
begin
  Ok := True; 
  Top := Nil; 
  while Ok do 
  begin
    writeln('Добавь число:'); 
    readln(Value); 
    if (Value = 999) then Ok := False
    else 
    begin
      New(Kon); 
      Kon^.Next := Top; 
      Kon^.Inf := Value; 
      Top := Kon; 
    end;
  end;
end;

procedure ViewStack(Top: Ptr); 
begin
  Kon := Top; 
  while Kon <> Nil do 
  begin
    writeln(Kon^.Inf); 
    Kon := Kon^.Next; 
  end;
end;

procedure DeleteTop(Var Top: Ptr);
begin
  Top:=Top^.Next;
end;

procedure ReversedStack(Top: Ptr); 
Var temp, Reversed: Ptr; // temp - вспомогательный 
begin
  Reversed := Nil; 
  
  while Top <> Nil do 
  begin
    New(temp); 
    temp^.Inf := Top^.Inf; 
    temp^.Next := Reversed; 
    
    Reversed := temp; 
    DeleteTop(Top); 
  end;
  
  Top := Reversed; 
end;

procedure DeleteStack(Top: Ptr); 
begin
  Top := Nil; 
end;

procedure MergeStacks(Top1, Top2: Ptr; var MergedStack: Ptr);
var
  Kon: Ptr;
begin
  MergedStack := Nil;

  while Top1 <> Nil do
  begin
    New(Kon);
    Kon^.Inf := Top1^.Inf;
    Kon^.Next := MergedStack;
    MergedStack := Kon;
    DeleteLast(Top1);
  end;

  while Top2 <> Nil do
  begin
    New(Kon);
    Kon^.Inf := Top2^.Inf;
    Kon^.Next := MergedStack;
    MergedStack := Kon;
    DeleteLast(Top2);
  end;
end;