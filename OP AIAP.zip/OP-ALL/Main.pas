﻿program MainMenu;

uses
  CRT,
  Compl,          // комплексные числа
  CMatr,          // комплексные матрицы
  VectReal,       // вещественные векторы
  VectCompl,      // комплексные векторы
  SStack,         // стеки
  QQueu,          // очереди (дополнен, см. ниже)
  DynamicTree,    // динамическое дерево → RunDynamicLab
  Tree,           // дерево из файла → RunTreeLab
  BinaryTree,     // бинарное дерево поиска → RunBinaryTreeLab
  FileStudent;    // файлы студентов

var
  Choice: Integer;

begin
  repeat
    ClrScr;
    Writeln('============================================');
    Writeln('          ГЛАВНОЕ МЕНЮ (все модули)');
    Writeln('============================================');
    Writeln(' 1. Комплексные числа');
    Writeln(' 2. Комплексные матрицы');
    Writeln(' 3. Вещественные векторы');
    Writeln(' 4. Комплексные векторы');
    Writeln(' 5. Стеки');
    Writeln(' 6. Очереди');
    Writeln(' 7. Динамическое дерево');
    Writeln(' 8. Дерево из файла (ЛР5)');
    Writeln(' 9. Бинарное дерево поиска');
    Writeln('10. Работа с файлами студентов');
    Writeln(' 0. Выход');
    Writeln('============================================');
    Write('Выберите пункт: ');
    ReadLn(Choice);

    case Choice of
      1:  menuComplex;
      2:  MenuCMatr;
      3:  MenuRVect;
      4:  MenuCVect;
      5:  MenuSStack;
      6:  MenuQueu;            // реализована в QQueu.pas
      7:  RunDynamicLab;       // из DynamicTree
      8:  RunTreeLab;          // из Tree
      9:  RunBinaryTreeLab;    // из BinaryTree
     10:  MenuFileStudent;
      0:  Writeln('Завершение программы...');
      else
        Writeln('Неверный пункт меню!');
        ReadLn;
    end;

  until Choice = 0;
end.