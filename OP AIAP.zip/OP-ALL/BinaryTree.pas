﻿unit BinaryTree;

interface

uses CRT;

procedure RunBinaryTreeLab;

implementation

type
  NodePtr = ^Node;

  Node = record
    Key: Integer;
    Left, Right: NodePtr;
  end;

var
  Top: NodePtr;

{--------------------------------------------------}
{ Добавление узла в бинарное дерево поиска        }
{--------------------------------------------------}
procedure MakeNode(NewKey: Integer; var Top: NodePtr);
begin
  if Top = Nil then
  begin
    New(Top);
    Top^.Key := NewKey;
    Top^.Left := Nil;
    Top^.Right := Nil;
  end
  else
    if NewKey < Top^.Key then
      MakeNode(NewKey, Top^.Left)
    else
      MakeNode(NewKey, Top^.Right);
end;

{--------------------------------------------------}
{ Создание дерева пользователем                    }
{--------------------------------------------------}
procedure MakeTree(var Top: NodePtr);
var
  i, n: Integer;
  InputKey: Integer;
begin
  Top := Nil;

  Write('Количество элементов: ');
  ReadLn(n);

  for i := 1 to n do
  begin
    Write('Введите ключ №', i, ': ');
    ReadLn(InputKey);
    MakeNode(InputKey, Top);
  end;
end;

{--------------------------------------------------}
{ Прямой обход                                     }
{--------------------------------------------------}
procedure WayUpDown(Top: NodePtr);
begin
  if Top <> Nil then
  begin
    Write(Top^.Key, ' ');
    WayUpDown(Top^.Left);
    WayUpDown(Top^.Right);
  end;
end;

{--------------------------------------------------}
{ Обратный обход                                   }
{--------------------------------------------------}
procedure WayDownUp(Top: NodePtr);
begin
  if Top <> Nil then
  begin
    WayDownUp(Top^.Left);
    WayDownUp(Top^.Right);
    Write(Top^.Key, ' ');
  end;
end;

{--------------------------------------------------}
{ Высота дерева                                    }
{--------------------------------------------------}
function High(Top: NodePtr): Integer;
var
  LeftH, RightH: Integer;
begin
  if Top = Nil then
    High := 0
  else
  begin
    LeftH := High(Top^.Left);
    RightH := High(Top^.Right);

    if LeftH > RightH then
      High := LeftH + 1
    else
      High := RightH + 1;
  end;
end;

{--------------------------------------------------}
{ Рекурсивная графическая отрисовка структуры      }
{--------------------------------------------------}
procedure DrawTreeGraph(CurrentTop: NodePtr; X, Y, Offset: Integer);
begin
  if CurrentTop <> Nil then
  begin
    // Выводим числовой ключ текущего узла
    GotoXY(X, Y);
    Write(CurrentTop^.Key);

    // Рисуем веточку влево
    if CurrentTop^.Left <> Nil then
    begin
      GotoXY(X - (Offset div 2), Y + 1);
      Write('/');
    end;

    // Рисуем веточку вправо
    if CurrentTop^.Right <> Nil then
    begin
      GotoXY(X + (Offset div 2), Y + 1);
      Write('\');
    end;

    // Рекурсивный спуск с делением смещения пополам
    DrawTreeGraph(CurrentTop^.Left, X - Offset, Y + 2, Offset div 2);
    DrawTreeGraph(CurrentTop^.Right, X + Offset, Y + 2, Offset div 2);
  end;
end;

{--------------------------------------------------}
{ Главная процедура красивого вывода дерева        }
{--------------------------------------------------}
procedure ViewTree(Top: NodePtr);
var
  TreeHeight: Integer;
  StartOffset: Integer;
begin
  if Top = Nil then
  begin
    Writeln('Дерево пустое.');
    Exit;
  end;

  ClrScr;
  TreeHeight := High(Top);

  Writeln('=== ГРАФИЧЕСКОЕ ПРЕДСТАВЛЕНИЕ ДЕРЕВА ===');

  // Подбираем оптимальный стартовый отступ под высоту дерева поиска
  if TreeHeight <= 3 then
    StartOffset := 6
  else if TreeHeight = 4 then
    StartOffset := 10
  else
    StartOffset := 16;

  // Отрисовка: 40 - центр экрана по горизонтали, 4 - верхняя строка
  DrawTreeGraph(Top, 40, 4, StartOffset);

  // Спускаем курсор вниз, чтобы служебный текст не затирал дерево
  GotoXY(1, 6 + TreeHeight * 2);
end;

{--------------------------------------------------}
{ Поиск узла                                       }
{--------------------------------------------------}
function SearchNode(Top: NodePtr; SearchKey: Integer): NodePtr;
begin
  if Top = Nil then
    SearchNode := Nil
  else
    if Top^.Key = SearchKey then
      SearchNode := Top
    else
      if SearchKey < Top^.Key then
        SearchNode := SearchNode(Top^.Left, SearchKey)
      else
        SearchNode := SearchNode(Top^.Right, SearchKey);
end;

{--------------------------------------------------}
{ Очистка памяти                                   }
{--------------------------------------------------}
procedure DeleteTree(var Top: NodePtr);
begin
  if Top <> Nil then
  begin
    DeleteTree(Top^.Left);
    DeleteTree(Top^.Right);
    Dispose(Top);
    Top := Nil;
  end;
end;
{--------------------------------------------------}
{ Вывод узлов указанного уровня                    }
{--------------------------------------------------}
procedure WayHoriz(Top: NodePtr; Level: Integer);
begin
  if Top <> Nil then
    if Level = 1 then
      Write(Top^.Key, ' ')
    else
    begin
      WayHoriz(Top^.Left, Level - 1);
      WayHoriz(Top^.Right, Level - 1);
    end;
end;
{--------------------------------------------------}
{ Показать все узлы выбранного уровня              }
{--------------------------------------------------}
procedure ShowLevel(Top: NodePtr);
var
  Level: Integer;
begin
  if Top = Nil then
  begin
    Writeln('Дерево пустое.');
    Exit;
  end;

  Write('Введите номер уровня: ');
  ReadLn(Level);

  if (Level < 1) or (Level > High(Top)) then
  begin
    Writeln('Такого уровня не существует.');
    Exit;
  end;

  Writeln('Узлы уровня ', Level, ':');
  WayHoriz(Top, Level);
  Writeln;
end;
{--------------------------------------------------}
{ Меню лабораторной работы                         }
{--------------------------------------------------}
procedure RunBinaryTreeLab;
var
  Choice: Integer;
  Key: Integer;
begin
  repeat
    ClrScr;

    Writeln('===== БИНАРНОЕ ДЕРЕВО =====');
    Writeln('1. Создать дерево');
    Writeln('2. Прямой обход');
    Writeln('3. Обратный обход');
    Writeln('4. Показать красивую структуру');
    Writeln('5. Высота дерева');
    Writeln('6. Поиск узла');
    Writeln('7. Удалить дерево');
    Writeln('8. Показать узлы уровня');
    Writeln('0. Назад');
    Writeln('---------------------------');

    Write('Ваш выбор: ');
    ReadLn(Choice);

    case Choice of

      1:
      begin
        DeleteTree(Top); // Сначала удаляем старое дерево, чтобы не плодить мусор в ОЗУ
        MakeTree(Top);
        Writeln('Дерево создано.');
        ReadLn;
      end;

      2:
      begin
        Writeln('Прямой обход:');
        WayUpDown(Top);
        Writeln;
        ReadLn;
      end;

      3:
      begin
        Writeln('Обратный обход:');
        WayDownUp(Top);
        Writeln;
        ReadLn;
      end;

      4:
      begin
        ViewTree(Top);
        Writeln('Нажмите Enter для возврата в меню...');
        ReadLn;
      end;

      5:
      begin
        Writeln('Высота дерева = ', High(Top));
        ReadLn;
      end;

      6:
      begin
        Write('Введите ключ: ');
        ReadLn(Key);

        if SearchNode(Top, Key) <> Nil then
          Writeln('Узел найден')
        else
          Writeln('Узел не найден');

        ReadLn;
      end;

      7:
      begin
        DeleteTree(Top);
        Writeln('Дерево удалено');
        ReadLn;
      end;
      8:
      begin
        ShowLevel(Top);
        ReadLn;
      end;
    end;

  until Choice = 0;
end;

begin
  Top := Nil;
end.
