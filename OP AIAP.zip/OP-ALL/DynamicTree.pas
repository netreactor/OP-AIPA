﻿unit DynamicTree;

interface

uses CRT;

procedure RunDynamicLab;

implementation

type
  NodePtr = ^Node;

  Node = record
    Name: Char;
    Left, Right: NodePtr;
  end;

var
  Top: NodePtr;

{----------------------------------}
{ Создание дерева }
{----------------------------------}

procedure MakeSubTrees(var Leaf: NodePtr);
var
  Key: Char;
begin
  Write('Введите символ узла: ');
  ReadLn(Leaf^.Name);

  Write('Есть левый потомок? (y/n): ');
  ReadLn(Key);

  if Key in ['y','Y'] then
  begin
    New(Leaf^.Left);
    MakeSubTrees(Leaf^.Left);
  end
  else
    Leaf^.Left := Nil;

  Write('Есть правый потомок? (y/n): ');
  ReadLn(Key);

  if Key in ['y','Y'] then
  begin
    New(Leaf^.Right);
    MakeSubTrees(Leaf^.Right);
  end
  else
    Leaf^.Right := Nil;
end;

procedure MakeTree(var Top: NodePtr);
begin
  New(Top);
  MakeSubTrees(Top);
end;

{----------------------------------}
{ Прямой обход }
{----------------------------------}

procedure WayUpDownDynamic(Top: NodePtr);
begin
  if Top <> Nil then
  begin
    Write(Top^.Name,' ');
    WayUpDownDynamic(Top^.Left);
    WayUpDownDynamic(Top^.Right);
  end;
end;

{----------------------------------}
{ Обратный обход }
{----------------------------------}

procedure WayDownUpDynamic(Top: NodePtr);
begin
  if Top <> Nil then
  begin
    WayDownUpDynamic(Top^.Left);
    WayDownUpDynamic(Top^.Right);
    Write(Top^.Name,' ');
  end;
end;

{----------------------------------}
{ Высота дерева }
{----------------------------------}

function High(Top: NodePtr): Integer;
var
  L,R: Integer;
begin
  if Top = Nil then
    High := 0
  else
  begin
    L := High(Top^.Left);
    R := High(Top^.Right);

    if L > R then
      High := L + 1
    else
      High := R + 1;
  end;
end;

{----------------------------------}
{ Вывод уровня }
{----------------------------------}

procedure WayHoriz(Top: NodePtr; Level: Integer);
begin
  if Top <> Nil then
    if Level = 1 then
      Write(Top^.Name,' ')
    else
    begin
      WayHoriz(Top^.Left,Level-1);
      WayHoriz(Top^.Right,Level-1);
    end;
end;

{----------------------------------}
{ Рекурсивная графическая отрисовка структуры }
{----------------------------------}

procedure DrawTreeGraph(CurrentTop: NodePtr; X, Y, Offset: Integer);
begin
  if CurrentTop <> Nil then
  begin
    // 1. Выводим символ текущего узла ровно по центру выделенного сектора
    GotoXY(X, Y);
    Write(CurrentTop^.Name);

    // 2. Рисуем веточку влево (смещение на 2-3 позиции в зависимости от уровня)
    if CurrentTop^.Left <> Nil then
    begin
      GotoXY(X - (Offset div 2), Y + 1);
      Write('/');
    end;

    // 3. Рисуем веточку вправо
    if CurrentTop^.Right <> Nil then
    begin
      GotoXY(X + (Offset div 2), Y + 1);
      Write('\');
    end;

    // 4. Рекурсивный спуск: делим Offset строго пополам, чтобы уровни не разъезжались
    DrawTreeGraph(CurrentTop^.Left, X - Offset, Y + 2, Offset div 2);
    DrawTreeGraph(CurrentTop^.Right, X + Offset, Y + 2, Offset div 2);
  end;
end;

procedure ViewTree(Top: NodePtr);
var
  TreeHeight: Integer;
  StartOffset: Integer;
begin
  if Top = Nil then
  begin
    Writeln('Дерево пустое.');
    Exit;
  end;

  ClrScr;
  TreeHeight := High(Top);

  Writeln('=== ГРАФИЧЕСКОЕ ПРЕДСТАВЛЕНИЕ ДЕРЕВА ===');

  // Динамически вычисляем стартовый отступ на основе высоты дерева.
  // Теперь для дерева высотой 3-4 уровня отступ не будет гигантским.
  if TreeHeight <= 3 then
    StartOffset := 6
  else if TreeHeight = 4 then
    StartOffset := 10
  else
    StartOffset := 16;

  // Отрисовка: 40 - центр экрана, 4 - стартовая строка
  DrawTreeGraph(Top, 40, 4, StartOffset);

  // Сдвигаем курсор под дерево, чтобы надпись не наложилась на узлы
  GotoXY(1, 6 + TreeHeight * 2);
end;

{----------------------------------}
{ Поиск узла }
{----------------------------------}

function SearchNode(Top: NodePtr; Symbol: Char): NodePtr;
var
  Temp: NodePtr;
begin
  SearchNode := Nil;

  if Top = Nil then Exit;

  if Top^.Name = Symbol then
  begin
    SearchNode := Top;
    Exit;
  end;

  Temp := SearchNode(Top^.Left,Symbol);

  if Temp <> Nil then
  begin
    SearchNode := Temp;
    Exit;
  end;

  SearchNode := SearchNode(Top^.Right,Symbol);
end;

{----------------------------------}
{ Удаление дерева }
{----------------------------------}

procedure DeleteTree(var Top: NodePtr);
begin
  if Top <> Nil then
  begin
    DeleteTree(Top^.Left);
    DeleteTree(Top^.Right);

    Dispose(Top);
    Top := Nil;
  end;
end;

{----------------------------------}
{ Добавление поддерева }
{----------------------------------}

procedure AddSubTree(Top: NodePtr);
var
  Symbol: Char;
  Leaf: NodePtr;
  Side: Char;
begin
  Write('Введите узел, к которому добавляем: ');
  ReadLn(Symbol);

  Leaf := SearchNode(Top,Symbol);

  if Leaf = Nil then
  begin
    Writeln('Узел не найден.');
    Exit;
  end;

  Write('Куда добавить? (L/R): ');
  ReadLn(Side);

  if (Side='L') or (Side='l') then
  begin
    if Leaf^.Left <> Nil then
    begin
      Writeln('Левое поддерево уже существует.');
      Exit;
    end;

    New(Leaf^.Left);
    MakeSubTrees(Leaf^.Left);
  end
  else
  begin
    if Leaf^.Right <> Nil then
    begin
      Writeln('Правое поддерево уже существует.');
      Exit;
    end;

    New(Leaf^.Right);
    MakeSubTrees(Leaf^.Right);
  end;
end;

{----------------------------------}
{ Удаление поддерева }
{----------------------------------}

procedure DeleteSubTree(var Top: NodePtr);
var
  Symbol: Char;
  Parent,Target: NodePtr;
  
{----------------------------------}
{ Показать все узлы уровня }
{----------------------------------}

procedure ShowLevel(Top: NodePtr);
var
  Level: Integer;
begin
  if Top = Nil then
  begin
    Writeln('Дерево пустое.');
    Exit;
  end;

  Write('Введите номер уровня: ');
  ReadLn(Level);

  if (Level < 1) or (Level > High(Top)) then
  begin
    Writeln('Такого уровня нет.');
    Exit;
  end;

  Writeln('Узлы уровня ', Level, ':');
  WayHoriz(Top, Level);
  Writeln;
end;

  procedure FindParent(Current: NodePtr);
  begin
    if (Current = Nil) or (Target <> Nil) then Exit; // Защита от зависания стека

    if (Current^.Left<>Nil) and
       (Current^.Left^.Name=Symbol) then
    begin
      Parent := Current;
      Target := Current^.Left;
      Exit;
    end;

    if (Current^.Right<>Nil) and
       (Current^.Right^.Name=Symbol) then
    begin
      Parent := Current;
      Target := Current^.Right;
      Exit;
    end;

    FindParent(Current^.Left);
    FindParent(Current^.Right);
  end;

begin
  Write('Введите корень удаляемого поддерева: ');
  ReadLn(Symbol);

  Parent := Nil;
  Target := Nil;

  if (Top<>Nil) and (Top^.Name=Symbol) then
  begin
    DeleteTree(Top);
    Writeln('Дерево удалено.');
    Exit;
  end;

  FindParent(Top);

  if Target = Nil then
  begin
    Writeln('Узел не найден.');
    Exit;
  end;

  if Parent^.Left = Target then
    Parent^.Left := Nil
  else
    Parent^.Right := Nil;

  DeleteTree(Target);

  Writeln('Поддерево удалено.');
end;

procedure ShowLevel(Top: NodePtr);
var
  Level: Integer;
begin
  Write('Введите уровень: ');
  ReadLn(Level);

  WayHoriz(Top, Level);
  Writeln;
end;

{----------------------------------}
{ Меню лабораторной }
{----------------------------------}

procedure RunDynamicLab;
var
  Choice: Integer;
  Symbol: Char;
begin
  repeat
    ClrScr;

    Writeln('1. Создать дерево');
    Writeln('2. Прямой обход');
    Writeln('3. Обратный обход');
    Writeln('4. Высота дерева');
    Writeln('5. Показать красивую структуру');
    Writeln('6. Поиск узла');
    Writeln('7. Добавить поддерево');
    Writeln('8. Удалить поддерево');
    Writeln('9. Удалить всё дерево');
    Writeln('10. Показать узлы уровня');
    Writeln('0. Назад');

    Write('Выбор: ');
    ReadLn(Choice);

    case Choice of

      1:
      begin
        DeleteTree(Top);
        MakeTree(Top);
      end;
    
      2:
      begin
        Writeln('Просмотр сверху вниз (Прямой обход):');
        WayUpDownDynamic(Top);
        Writeln;
        ReadLn;
      end;
    
      3:
      begin
        Writeln('Просмотр снизу вверх (Обратный обход):');
        WayDownUpDynamic(Top);
        Writeln;
        ReadLn;
      end;
    
      4:
      begin
        Writeln('Высота дерева = ', High(Top));
        ReadLn;
      end;
    
      5:
      begin
        ViewTree(Top);
        Writeln('Нажмите Enter для возврата в меню...');
        ReadLn;
      end;
    
      6:
      begin
        Write('Введите символ для поиска: ');
        ReadLn(Symbol);
        if SearchNode(Top, Symbol) <> Nil then
          Writeln('Узел найден.')
        else
          Writeln('Узел не найден.');
        ReadLn;
      end;
    
      7:
      begin
        AddSubTree(Top);
        ReadLn;
      end;
    
      8:
      begin
        DeleteSubTree(Top);
        ReadLn;
      end;
    
      9:
      begin
        DeleteTree(Top);
        Writeln('Дерево удалено');
        ReadLn;
      end;
      10:
      begin
        ShowLevel(Top);
        ReadLn;
      end;

    end;

  until Choice = 0;
end;

begin
  Top := Nil;
end.
