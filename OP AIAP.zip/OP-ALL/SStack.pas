﻿Unit SStack; 

Interface 

Uses 
  CRT; 

Type Ptr = ^Stak; 
Stak = record 
  Inf: integer; 
  Next: Ptr;  
end;

procedure MakeStack(Var Top: Ptr); 
procedure AddStack(Var Top: Ptr); 
procedure ViewStack(Top: Ptr); 
procedure DeleteTop(Var Top: Ptr);
procedure ReversedStack(Var Top: Ptr);  
procedure DeleteStack(Var Top: Ptr);    
procedure MergeStacks(Var Top1, Top2, MergedStack: Ptr); 
procedure Wait; 
procedure MenuSStack(); 

Implementation 

procedure MakeStack(Var Top: Ptr); 
Var Value: integer;
    Ok: boolean; 
    Kon: Ptr;
begin
  Ok := True; 
  Top := Nil; 
  while Ok do 
  begin
    writeln('Введите число (999 - выход):'); 
    readln(Value); 
    if (Value = 999) then 
      Ok := False
    else 
    begin
      New(Kon); 
      Kon^.Next := Top; 
      Kon^.Inf := Value; 
      Top := Kon; 
    end;
  end;
end;

procedure AddStack(Var Top: Ptr); 
Var Value: integer;
    Ok: boolean; 
    Kon: Ptr;
begin
  Ok := True; 
  while Ok do 
  begin
    writeln('Добавь число (999 - выход):'); 
    readln(Value); 
    if (Value = 999) then 
      Ok := False
    else 
    begin
      New(Kon); 
      Kon^.Next := Top; 
      Kon^.Inf := Value; 
      Top := Kon; 
    end;
  end;
end;

procedure ViewStack(Top: Ptr); 
var Kon: Ptr;
begin
  Kon := Top; 
  while Kon <> Nil do 
  begin
    writeln(Kon^.Inf); 
    Kon := Kon^.Next; 
  end;
end;

procedure DeleteTop(Var Top: Ptr);
var Temp: Ptr;
begin
  if Top <> Nil then
  begin
    Temp := Top;
    Top := Top^.Next;
    Dispose(Temp);  
  end;
end;

procedure ReversedStack(Var Top: Ptr); 
Var temp, Reversed, Current: Ptr;
begin
  Reversed := Nil; 
  Current := Top;
  
  while Current <> Nil do 
  begin
    New(temp); 
    temp^.Inf := Current^.Inf; 
    temp^.Next := Reversed; 
    Reversed := temp; 
    Current := Current^.Next;
  end;
  
  while Top <> Nil do
    DeleteTop(Top);
  
  Top := Reversed; 
end;

procedure DeleteStack(Var Top: Ptr); 
var Temp: Ptr;
begin
  while Top <> Nil do
  begin
    Temp := Top;
    Top := Top^.Next;
    Dispose(Temp);
  end;
end;

procedure MergeStacks(Var Top1, Top2, MergedStack: Ptr);
var
  Kon, Current: Ptr;
begin
  MergedStack := Nil;

  Current := Top1;
  while Current <> Nil do
  begin
    New(Kon);
    Kon^.Inf := Current^.Inf;
    Kon^.Next := MergedStack;
    MergedStack := Kon;
    Current := Current^.Next;
  end;

  Current := Top2;
  while Current <> Nil do
  begin
    New(Kon);
    Kon^.Inf := Current^.Inf;
    Kon^.Next := MergedStack;
    MergedStack := Kon;
    Current := Current^.Next;
  end;
end;

procedure Wait;
begin
  repeat until KeyPressed;
  while KeyPressed do ReadKey;
end;

procedure MenuSStack();
var 
  Mode: integer;
  Ok: boolean;
  Stack1, Stack2, MergedStack: Ptr;
begin
  Stack1 := Nil;
  Stack2 := Nil;
  MergedStack := Nil;
  Ok := true;
  
  while Ok do
  begin
    ClrScr;
    writeln('========== УПРАВЛЕНИЕ СТЕКАМИ ==========');
    writeln('1) Создание стека (стек 1)');
    writeln('2) Добавить элемент в стек (стек 1)');
    writeln('3) Просмотр стека (стек 1)');
    writeln('4) Удаление последнего элемента стека (стек 1)');
    writeln('5) Перевернуть стек (стек 1)');
    writeln('6) Удалить стек (стек 1)');
    writeln('7) Создание второго стека (стек 2)');
    writeln('8) Добавить элемент во второй стек (стек 2)');
    writeln('9) Просмотр второго стека (стек 2)');
    writeln('10) Объединение стеков (стек1 + стек2)');
    writeln('11) Просмотр объединенного стека');
    writeln('0) Выход');
    writeln('=========================================');
    write('Выберите режим: ');
    readln(Mode);

    case Mode of
      1: 
      begin
        ClrScr;
        writeln('=== СОЗДАНИЕ СТЕКА ===');
        MakeStack(Stack1);
        writeln('Стек создан!');
        Wait;
      end;
      2:
      begin
        ClrScr;
        writeln('=== ДОБАВЛЕНИЕ В СТЕК ===');
        if Stack1 = Nil then
          writeln('Стек не создан! Сначала создайте стек (пункт 1)')
        else
          AddStack(Stack1);
        Wait;
      end;
      3:
      begin
        ClrScr;
        writeln('=== ПРОСМОТР СТЕКА ===');
        if Stack1 = Nil then
          writeln('Стек не создан!')
        else
          ViewStack(Stack1);
        Wait;
      end;
      4:
      begin
        ClrScr;
        writeln('=== УДАЛЕНИЕ ВЕРХНЕГО ЭЛЕМЕНТА ===');
        if Stack1 = Nil then
          writeln('Стек не создан!')
        else
          DeleteTop(Stack1);
        Wait;
      end;
      5:
      begin
        ClrScr;
        writeln('=== ПЕРЕВОРОТ СТЕКА ===');
        if Stack1 = Nil then
          writeln('Стек не создан!')
        else
          ReversedStack(Stack1);
        Wait;
      end;
      6:
      begin
        ClrScr;
        writeln('=== УДАЛЕНИЕ СТЕКА ===');
        if Stack1 = Nil then
          writeln('Стек не создан!')
        else
          DeleteStack(Stack1);
        Wait;
      end;
      7:
      begin
        ClrScr;
        writeln('=== СОЗДАНИЕ ВТОРОГО СТЕКА ===');
        MakeStack(Stack2);
        writeln('Второй стек создан!');
        Wait;
      end;
      8:
      begin
        ClrScr;
        writeln('=== ДОБАВЛЕНИЕ ВО ВТОРОЙ СТЕК ===');
        if Stack2 = Nil then
          writeln('Второй стек не создан! Сначала создайте стек (пункт 7)')
        else
          AddStack(Stack2);
        Wait;
      end;
      9:
      begin
        ClrScr;
        writeln('=== ПРОСМОТР ВТОРОГО СТЕКА ===');
        if Stack2 = Nil then
          writeln('Второй стек не создан!')
        else
          ViewStack(Stack2);
        Wait;
      end;
      10:
      begin
        ClrScr;
        writeln('=== ОБЪЕДИНЕНИЕ СТЕКОВ ===');
        if (Stack1 = Nil) and (Stack2 = Nil) then
          writeln('Оба стека пусты!')
        else if (Stack1 = Nil) then
          writeln('Первый стек пуст!')
        else if (Stack2 = Nil) then
          writeln('Второй стек пуст!')
        else
        begin
          MergeStacks(Stack1, Stack2, MergedStack);
          writeln('Объединение выполнено! Результат сохранен в объединенном стеке.');
        end;
        Wait;
      end;
      11:
      begin
        ClrScr;
        writeln('=== ПРОСМОТР ОБЪЕДИНЕННОГО СТЕКА ===');
        if MergedStack = Nil then
          writeln('Объединенный стек пуст! Сначала выполните объединение (пункт 10)')
        else
          ViewStack(MergedStack);
        Wait;
      end;
      0: 
        begin
          if Stack1 <> Nil then DeleteStack(Stack1);
          if Stack2 <> Nil then DeleteStack(Stack2);
          if MergedStack <> Nil then DeleteStack(MergedStack);
          Ok := false;
          writeln('Программа завершена.');
        end;
      else
      begin
        writeln('Ошибка! Неверный режим. Повторите ввод.');
        Wait;
      end;
    end;
  end;
end;

end.

