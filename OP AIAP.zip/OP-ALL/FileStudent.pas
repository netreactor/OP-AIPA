﻿Unit FileStudent;

Interface

Uses CRT;

Type 
  Student = record
    Name: string[10];
    Mark: string[3];
  end;

procedure MakeFile;
procedure ViewFile;
procedure AddFile;
procedure Wait; 
procedure MenuFileStudent(); 

Implementation

procedure MakeFile;
var 
  ch: char; 
  ok: boolean;
  FileName: string[12];
  StudentFile: file of Student;
  FlowStudent: Student;
begin
  ok := true;
  writeln('Дайте файлу имя');
  readln(FileName);
  assign(StudentFile, FileName);
  rewrite(StudentFile);
  with FlowStudent do
    while ok do
    begin
      GoToXY(30,10); writeln('Будете еще вводить?');
      GoToXY(30,11); readln(ch);
      GoToXY(30,11); ClearLine;
      if ch in ['n','N','т','T'] then
      begin
        ok := false;
        Close(StudentFile);
      end
      else
      begin
        GoToXY(30,20); writeln('Введите фамилию студента');
        GoToXY(30,21); readln(Name);
        GoToXY(30,20); ClearLine;
        GoToXY(30,21); ClearLine;
        GoToXY(30,20); writeln('Введите оценки студента');
        GoToXY(30,21); readln(Mark);
        GoToXY(30,20); ClearLine;
        GoToXY(30,21); ClearLine;
        write(StudentFile,FlowStudent);
      end;
    end;
end;

procedure ViewFile;
var 
  ch: char; 
  k: integer;
  FileName: string[12];
  StudentFile: file of Student;
  FlowStudent: Student;
begin
  k := 3;
  writeln('Введите имя файла');
  readln(FileName);
  assign(StudentFile, FileName);
  reset(StudentFile);
  with FlowStudent do
    while not EOF(StudentFile) do
    begin
      k := k + 1;
      read(StudentFile,FlowStudent);
      GoToXY(1,k); write(Name);
      GoToXY(11,k); write(Mark);
    end;
    Close(StudentFile);
end;

procedure AddFile;
var 
  ch: char; 
  ok: boolean;
  FileName, NewName: string[12];
  StudentFile, NewFile: file of Student;
  FlowStudent: Student;
begin
  Ok := true;
  writeln('Введите имя файла');
  readln(FileName);
  assign(StudentFile, FileName);
  reset(StudentFile);
  NewName := 'aaaaa';
  assign(NewFile, NewName);
  rewrite(NewFile);
  while not EOF(StudentFile) do
  begin
    read(StudentFile, FlowStudent);
    write(NewFile, FlowStudent);
  end;
  with FlowStudent do
    while Ok do
    begin
      GoToXY(30,10); writeln('Будете еще вводить?');
      GoToXY(30,11); readln(ch);
      GoToXY(30,11); ClearLine;
      if ch in ['n','N','т','T'] then
      begin
        Ok := false;
        Close(StudentFile); 
        Erase(StudentFile);
        rename(NewFile,FileName);
      end
      else
      begin
        GoToXY(30,20); writeln('Введите фамилию студента');
        GoToXY(30,21); readln(Name);
        GoToXY(30,20); ClearLine;
        GoToXY(30,21); ClearLine;
        GoToXY(30,20); writeln('Введите оценки студента');
        GoToXY(30,21); readln(Mark);
        GoToXY(30,20); ClearLine;
        GoToXY(30,21); ClearLine;
        write(NewFile,FlowStudent);
      end;
    end;
end;

procedure Wait;
begin
  repeat until KeyPressed;
  while KeyPressed do ReadKey;
end;

procedure MenuFileStudent();
var 
  Mode: integer;
  Ok: boolean;
begin
  Ok := true;
  
  while Ok do
  begin
    ClrScr;
    writeln('========== УПРАВЛЕНИЕ ФАЙЛАМИ СТУДЕНТОВ ==========');
    writeln('1) Создание файла');
    writeln('2) Просмотр файла');
    writeln('3) Добавление в файл');
    writeln('0) Выход');
    writeln('===================================================');
    write('Выберите режим: ');
    readln(Mode);

    case Mode of
      1: 
      begin
        ClrScr;
        writeln('=== СОЗДАНИЕ ФАЙЛА ===');
        MakeFile;
        writeln('Файл создан!');
        Wait;
      end;
      2:
      begin
        ClrScr;
        writeln('=== ПРОСМОТР ФАЙЛА ===');
        ViewFile;
        writeln;
        writeln('Нажмите любую клавишу для продолжения...');
        Wait;
      end;
      3:
      begin
        ClrScr;
        writeln('=== ДОБАВЛЕНИЕ В ФАЙЛ ===');
        AddFile;
        writeln('Записи добавлены!');
        Wait;
      end;
      0:
      begin
        Ok := false;
        writeln('Выход из программы...');
      end;
      else
      begin
        writeln('Неверный режим! Попробуйте снова.');
        Wait;
      end;
    end;
  end;
end;


end.