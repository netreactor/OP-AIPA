import { Edge, Figure, Point, Polygon } from '../entities';

export class Pyramid extends Figure {
  constructor(size = 16, height = 18) {
    super();
    const a = size / 2;

    this.points.push(new Point(-a, -a, -height / 2));
    this.points.push(new Point(a, -a, -height / 2));
    this.points.push(new Point(a, a, -height / 2));
    this.points.push(new Point(-a, a, -height / 2));
    this.points.push(new Point(0, 0, height / 2));

    this.edges.push(new Edge(this.points[0], this.points[1]));
    this.edges.push(new Edge(this.points[1], this.points[2]));
    this.edges.push(new Edge(this.points[2], this.points[3]));
    this.edges.push(new Edge(this.points[3], this.points[0]));
    this.edges.push(new Edge(this.points[0], this.points[4]));
    this.edges.push(new Edge(this.points[1], this.points[4]));
    this.edges.push(new Edge(this.points[2], this.points[4]));
    this.edges.push(new Edge(this.points[3], this.points[4]));

    this.polygons.push(new Polygon([this.points[0], this.points[1], this.points[2], this.points[3]], '#d1d5dbaa'));
    this.polygons.push(new Polygon([this.points[4], this.points[0], this.points[1]], '#f87171aa'));
    this.polygons.push(new Polygon([this.points[4], this.points[1], this.points[2]], '#60a5faaa'));
    this.polygons.push(new Polygon([this.points[4], this.points[2], this.points[3]], '#4ade80aa'));
    this.polygons.push(new Polygon([this.points[4], this.points[3], this.points[0]], '#facc15aa'));
  }
}
