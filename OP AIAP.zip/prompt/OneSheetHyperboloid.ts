import { Edge, Figure, Point, Polygon } from '../entities';

export class OneSheetHyperboloid extends Figure {
    constructor(count = 30, a = 3, b = 3, c = 5) {
        super();

        const uMin = 0;
        const uMax = 2 * Math.PI;

        const vMin = -2;
        const vMax = 2;

        const uStep = (uMax - uMin) / count;
        const vStep = (vMax - vMin) / count;

        const cols = count + 1;

        // Точки
        for (let i = 0; i <= count; i += 1) {

            const u = uMin + i * uStep;

            for (let j = 0; j <= count; j += 1) {

                const v = vMin + j * vStep;

                const x =
                    a * Math.cosh(v) * Math.cos(u);

                const y =
                    b * Math.cosh(v) * Math.sin(u);

                const z =
                    c * Math.sinh(v);

                this.points.push(
                    new Point(x, y, z)
                );
            }
        }

        // Рёбра
        for (let i = 0; i <= count; i += 1) {

            const rowStart = i * cols;

            for (let j = 0; j < count; j += 1) {

                const current =
                    this.points[rowStart + j];

                // вправо
                this.edges.push(
                    new Edge(
                        current,
                        this.points[rowStart + j + 1]
                    )
                );

                // вниз
                if (i < count) {
                    this.edges.push(
                        new Edge(
                            current,
                            this.points[rowStart + j + cols]
                        )
                    );
                }
            }
        }

        // Замыкание по окружности
        for (let j = 0; j <= count; j += 1) {

            this.edges.push(
                new Edge(
                    this.points[j],
                    this.points[count * cols + j]
                )
            );
        }

        // Полигоны
        for (let i = 0; i < count; i += 1) {

            const rowStart = i * cols;
            const nextRowStart = rowStart + cols;

            for (let j = 0; j < count; j += 1) {

                this.polygons.push(
                    new Polygon([
                        this.points[rowStart + j],
                        this.points[rowStart + j + 1],
                        this.points[nextRowStart + j + 1],
                        this.points[nextRowStart + j]
                    ], '#4cc9f0')
                );
            }
        }

        // Замыкающие полигоны
        for (let j = 0; j < count; j += 1) {

            this.polygons.push(
                new Polygon([
                    this.points[j],
                    this.points[j + 1],
                    this.points[count * cols + j + 1],
                    this.points[count * cols + j]
                ], '#4cc9f0')
            );
        }
    }
}