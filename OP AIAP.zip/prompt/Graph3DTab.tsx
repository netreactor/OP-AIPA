import { useEffect, useRef, useState } from 'react';
import { type Figure, Point } from '../../lib/math3d/entities';
import { createFigure, type FigureType, FIGURE_OPTIONS } from '../../lib/math3d/figures';
import { Math3D, type Viewport3D } from '../../lib/math3d/math3d';

const CANVAS_SIZE = 600;

type ScreenPoint = {
  x: number;
  y: number;
};

const createViewport = (): Viewport3D => ({
  left: -20,
  bottom: -20,
  width: 40,
  height: 40,
  Camera: new Point(0, 0, 55),
  Focus: new Point(0, 0, 35),
});

const toScreen = (viewport: Viewport3D, x: number, y: number): ScreenPoint => ({
  x: ((x - viewport.left) / viewport.width) * CANVAS_SIZE,
  y: CANVAS_SIZE - ((y - viewport.bottom) / viewport.height) * CANVAS_SIZE,
});

const drawLine = (
  ctx: CanvasRenderingContext2D,
  start: ScreenPoint,
  end: ScreenPoint,
  color: string,
  width = 1,
) => {
  ctx.beginPath();
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.moveTo(start.x, start.y);
  ctx.lineTo(end.x, end.y);
  ctx.stroke();
};

const drawPoint = (
  ctx: CanvasRenderingContext2D,
  point: ScreenPoint,
  color = '#ff0000',
  size = 3,
) => {
  ctx.beginPath();
  ctx.fillStyle = color;
  ctx.arc(point.x, point.y, size, 0, Math.PI * 2);
  ctx.fill();
};

const drawPolygon = (
  ctx: CanvasRenderingContext2D,
  viewport: any,
  math3D: any,
  polygon: any,
) => {
  if (polygon.points.length < 3) return;

  const first = toScreen(
    viewport,
    math3D.xs(polygon.points[0]),
    math3D.ys(polygon.points[0]),
  );

  ctx.beginPath();
  ctx.moveTo(first.x, first.y);

  for (let i = 1; i < polygon.points.length; i++) {
    const pt = toScreen(
      viewport,
      math3D.xs(polygon.points[i]),
      math3D.ys(polygon.points[i]),
    );
    ctx.lineTo(pt.x, pt.y);
  }

  ctx.closePath();

  const lumen = 0.3 + 0.7 * polygon.lumen;
  const hex = polygon.color;
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);

  ctx.fillStyle = `rgb(${Math.round(r * lumen)}, ${Math.round(g * lumen)}, ${Math.round(b * lumen)})`;
  ctx.fill();
};

const renderScene = (
  ctx: CanvasRenderingContext2D,
  viewport: Viewport3D,
  math3D: Math3D,
  scene: Figure,
  fps: number,
  showEdges: boolean,
  showPoints: boolean,
) => {
  ctx.clearRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);
  ctx.fillStyle = '#eeeeee';
  ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

  if (scene.polygons.length) {
    scene.polygons.forEach((polygon) => {
      math3D.calcCenter(polygon);
      math3D.calcDistance(polygon, viewport.Camera, 'distance');
      math3D.calcLumens(polygon);
    });

    math3D.sortByArtist(scene.polygons);
    scene.polygons.forEach((polygon) => drawPolygon(ctx, viewport, math3D, polygon));
  }

  if (showEdges) {
    scene.edges.forEach((edge) => {
      const start = toScreen(viewport, math3D.xs(edge.p1), math3D.ys(edge.p1));
      const end = toScreen(viewport, math3D.xs(edge.p2), math3D.ys(edge.p2));
      drawLine(ctx, start, end, '#333333', 1);
    });
  }

  if (showPoints) {
    scene.points.forEach((point) => {
      const screenPoint = toScreen(viewport, math3D.xs(point), math3D.ys(point));
      drawPoint(ctx, screenPoint, '#ff0000', 1);
    });
  }

  ctx.fillStyle = '#000000';
  ctx.font = '16px Arial';
  ctx.fillText(`FPS: ${fps}`, 10, 24);
};

export default function Graph3DTab() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const canMoveRef = useRef(false);
  const viewportRef = useRef<Viewport3D>(createViewport());
  const math3DRef = useRef(new Math3D(viewportRef.current));
  const sceneRef = useRef<Figure>(createFigure('cube'));
  const fpsRef = useRef(0);
  const animationRef = useRef(false);

  const [selectedFigure, setSelectedFigure] = useState<FigureType>('cube');
  const [showEdges, setShowEdges] = useState(true);
  const [showPoints, setShowPoints] = useState(true);

  // Рефы для флагов, чтобы рендер-цикл видел актуальные значения без перезапуска
  const showEdgesRef = useRef(true);
  const showPointsRef = useRef(true);

  const handleToggleEdges = () => {
    const next = !showEdgesRef.current;
    showEdgesRef.current = next;
    setShowEdges(next);
  };

  const handleTogglePoints = () => {
    const next = !showPointsRef.current;
    showPointsRef.current = next;
    setShowPoints(next);
  };

  useEffect(() => {
    sceneRef.current = createFigure(selectedFigure);
  }, [selectedFigure]);

  useEffect(() => {
    let animationId = 0;
    let lastTime = performance.now();
    let frames = 0;
    let time = 0;

    const loop = (currentTime: number) => {
      const delta = currentTime - lastTime;
      lastTime = currentTime;
      frames += 1;
      time += delta;

      if (time >= 500) {
        fpsRef.current = Math.round((frames * 1000) / time);
        frames = 0;
        time = 0;
      }

      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');

      if (ctx) {
        if (animationRef.current) {
          sceneRef.current.points.forEach((point) => {
            math3DRef.current.rotateOy(0.01, point);
          });
        }

        renderScene(
          ctx,
          viewportRef.current,
          math3DRef.current,
          sceneRef.current,
          fpsRef.current,
          showEdgesRef.current,
          showPointsRef.current,
        );
      }

      animationId = window.requestAnimationFrame(loop);
    };

    animationId = window.requestAnimationFrame(loop);

    return () => window.cancelAnimationFrame(animationId);
  }, []);

  return (
    <section>
      <h2>Графики 3D</h2>

      <div className="canvas-container">
        <canvas
          ref={canvasRef}
          width={CANVAS_SIZE}
          height={CANVAS_SIZE}
          className="graph-canvas"
          onWheel={(event) => {
            event.preventDefault();
            const delta = event.deltaY < 0 ? 1.1 : 0.9;
            sceneRef.current.points.forEach((point) => math3DRef.current.zoom(delta, point));
          }}
          onMouseDown={() => {
            canMoveRef.current = true;
          }}
          onMouseUp={() => {
            canMoveRef.current = false;
          }}
          onMouseLeave={() => {
            canMoveRef.current = false;
          }}
          onMouseMove={(event) => {
            if (!canMoveRef.current) return;

            const alphaX = (event.movementX * Math.PI) / 360;
            const alphaY = (event.movementY * Math.PI) / 360;

            sceneRef.current.points.forEach((point) => {
              math3DRef.current.rotateOy(alphaX, point);
              math3DRef.current.rotateOx(alphaY, point);
            });
          }}
        />
      </div>

      <div className="form-row">
        <label>
          Фигура
          <select
            value={selectedFigure}
            onChange={(event) => setSelectedFigure(event.target.value as FigureType)}
          >
            {FIGURE_OPTIONS.map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
        </label>

        <button
          type="button"
          onClick={() => {
            animationRef.current = !animationRef.current;
          }}
        >
          Анимация
        </button>

        {/* Тоггл рёбер */}
        <button
          type="button"
          className={showEdges ? 'active-button' : ''}
          onClick={handleToggleEdges}
          title="Показать / скрыть рёбра"
        >
          {showEdges ? '✔ Рёбра' : '✘ Рёбра'}
        </button>

        {/* Тоггл точек */}
        <button
          type="button"
          className={showPoints ? 'active-button' : ''}
          onClick={handleTogglePoints}
          title="Показать / скрыть точки"
        >
          {showPoints ? '✔ Точки' : '✘ Точки'}
        </button>
      </div>
    </section>
  );
}
