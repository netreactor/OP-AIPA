import { Edge, Figure, Point, Polygon } from '../entities';

export class Cube extends Figure {
  constructor(size = 18) {
    super();
    const a = size / 2;

    this.points.push(new Point(-a, -a, -a));
    this.points.push(new Point(a, -a, -a));
    this.points.push(new Point(a, a, -a));
    this.points.push(new Point(-a, a, -a));
    this.points.push(new Point(-a, -a, a));
    this.points.push(new Point(a, -a, a));
    this.points.push(new Point(a, a, a));
    this.points.push(new Point(-a, a, a));

    this.edges.push(new Edge(this.points[0], this.points[1]));
    this.edges.push(new Edge(this.points[1], this.points[2]));
    this.edges.push(new Edge(this.points[2], this.points[3]));
    this.edges.push(new Edge(this.points[3], this.points[0]));
    this.edges.push(new Edge(this.points[4], this.points[5]));
    this.edges.push(new Edge(this.points[5], this.points[6]));
    this.edges.push(new Edge(this.points[6], this.points[7]));
    this.edges.push(new Edge(this.points[7], this.points[4]));
    this.edges.push(new Edge(this.points[0], this.points[4]));
    this.edges.push(new Edge(this.points[1], this.points[5]));
    this.edges.push(new Edge(this.points[2], this.points[6]));
    this.edges.push(new Edge(this.points[3], this.points[7]));

    this.polygons.push(new Polygon([this.points[0], this.points[3], this.points[2], this.points[1]], '#f87171aa'));
    this.polygons.push(new Polygon([this.points[1], this.points[5], this.points[6], this.points[2]], '#60a5faaa'));
    this.polygons.push(new Polygon([this.points[4], this.points[7], this.points[6], this.points[5]], '#facc15aa'));
    this.polygons.push(new Polygon([this.points[0], this.points[3], this.points[7], this.points[4]], '#4ade80aa'));
    this.polygons.push(new Polygon([this.points[3], this.points[2], this.points[6], this.points[7]], '#f472b6aa'));
    this.polygons.push(new Polygon([this.points[0], this.points[4], this.points[5], this.points[1]], '#fb923caa'));
  }
}
