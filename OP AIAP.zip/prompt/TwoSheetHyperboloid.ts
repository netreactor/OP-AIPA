import { Edge, Figure, Point, Polygon } from '../entities';

export class TwoSheetHyperboloid extends Figure {
    constructor(count = 25, a = 3, b = 3, c = 4) {
        super();

        const uMin = 0;
        const uMax = 2 * Math.PI;

        const vMin = 0;
        const vMax = 2;

        const uStep = (uMax - uMin) / count;
        const vStep = (vMax - vMin) / count;

        const cols = count + 1;

        // ===== ВЕРХНЯЯ ЧАСТЬ =====

        for (let i = 0; i <= count; i += 1) {

            const u = uMin + i * uStep;

            for (let j = 0; j <= count; j += 1) {

                const v = vMin + j * vStep;

                const x =
                    a * Math.sinh(v) * Math.cos(u);

                const y =
                    b * Math.sinh(v) * Math.sin(u);

                const z =
                    c * Math.cosh(v);

                this.points.push(
                    new Point(x, y, z)
                );
            }
        }

        // ===== НИЖНЯЯ ЧАСТЬ =====

        const offset = this.points.length;

        for (let i = 0; i <= count; i += 1) {

            const u = uMin + i * uStep;

            for (let j = 0; j <= count; j += 1) {

                const v = vMin + j * vStep;

                const x =
                    a * Math.sinh(v) * Math.cos(u);

                const y =
                    b * Math.sinh(v) * Math.sin(u);

                const z =
                    -c * Math.cosh(v);

                this.points.push(
                    new Point(x, y, z)
                );
            }
        }

        // ===== РЁБРА =====

        const buildEdges = (start: number) => {

            for (let i = 0; i <= count; i += 1) {

                const rowStart = start + i * cols;

                for (let j = 0; j < count; j += 1) {

                    const current =
                        this.points[rowStart + j];

                    // вправо
                    this.edges.push(
                        new Edge(
                            current,
                            this.points[rowStart + j + 1]
                        )
                    );

                    // вниз
                    if (i < count) {
                        this.edges.push(
                            new Edge(
                                current,
                                this.points[rowStart + j + cols]
                            )
                        );
                    }
                }
            }

            // замыкание
            for (let j = 0; j <= count; j += 1) {

                this.edges.push(
                    new Edge(
                        this.points[start + j],
                        this.points[start + count * cols + j]
                    )
                );
            }
        };

        buildEdges(0);
        buildEdges(offset);

        // ===== ПОЛИГОНЫ =====

        const buildPolygons = (start: number) => {

            for (let i = 0; i < count; i += 1) {

                const rowStart =
                    start + i * cols;

                const nextRowStart =
                    rowStart + cols;

                for (let j = 0; j < count; j += 1) {
                    const colorr = (i + j) % 2 === 0 ? '#ffffff' : '#000000';
                    this.polygons.push(
                        new Polygon([
                            this.points[rowStart + j],
                            this.points[rowStart + j + 1],
                            this.points[nextRowStart + j + 1],
                            this.points[nextRowStart + j]
                        ], colorr)
                    );
                }
            }

            // замыкающие полигоны
            for (let j = 0; j < count; j += 1) {
                const color = ((j) % 3 === 0) ? '#ffffff' : '#000000';
                this.polygons.push(
                    new Polygon([
                        this.points[start + j],
                        this.points[start + j + 1],
                        this.points[start + count * cols + j + 1],
                        this.points[start + count * cols + j]
                    ], color)
                );
            }
        };

        buildPolygons(0);
        buildPolygons(offset);
    }
}