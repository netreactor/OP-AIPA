import { Edge, Figure, Point, Polygon } from '../entities';

export class ParabolicCylinder extends Figure {
    constructor(count = 20, a = 4) {
        super();

        const xMin = -10;
        const xMax = 10;

        const zMin = -10;
        const zMax = 10;

        const xStep = (xMax - xMin) / count;
        const zStep = (zMax - zMin) / count;

        const cols = count + 1;

        // точки
        for (let i = 0; i <= count; i += 1) {

            const x = xMin + i * xStep;

            for (let j = 0; j <= count; j += 1) {

                const z = zMin + j * zStep;

                const y = (x * x) / (a * a);

                this.points.push(
                    new Point(x, y, z)
                );
            }
        }

        // рёбра
        for (let i = 0; i <= count; i += 1) {

            const rowStart = i * cols;

            for (let j = 0; j < count; j += 1) {

                const current = this.points[rowStart + j];

                // вдоль z
                this.edges.push(
                    new Edge(current, this.points[rowStart + j + 1])
                );

                // вдоль параболы
                if (i < count) {
                    this.edges.push(
                        new Edge(current, this.points[rowStart + j + cols])
                    );
                }
            }
        }

        // полигоны
        for (let i = 0; i < count; i += 1) {

            const rowStart = i * cols;
            const nextRowStart = rowStart + cols;

            for (let j = 0; j < count; j += 1) {
                const color =
                (i + j) % 2 === 0
                  ? '#ffffff'
                  : '#000000';
                this.polygons.push(
                    new Polygon([
                        this.points[rowStart + j],
                        this.points[rowStart + j + 1],
                        this.points[nextRowStart + j + 1],
                        this.points[nextRowStart + j]
                    ], 
                    color)
                );
            }
        }
    }
}