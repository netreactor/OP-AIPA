import { Edge, Figure, Point, Polygon } from '../entities';

export class Ellipsoid extends Figure {
  constructor(a = 12, b = 8, c = 6, count = 20) {
    super();
    const dTeta = Math.PI / count;
    const dPhi = (2 * Math.PI) / count;

    for (let i = 0; i <= count; i += 1) {
      const teta = dTeta * i;

      for (let j = 0; j < count; j += 1) {
        const phi = dPhi * j;
        const x = a * Math.sin(teta) * Math.cos(phi);
        const y = b * Math.sin(teta) * Math.sin(phi);
        const z = c * Math.cos(teta);
        this.points.push(new Point(x, y, z));
      }
    }

    for (let i = 0; i < this.points.length; i += 1) {
      if (this.points[i + 1]) {
        if ((i + 1) % count === 0) {
          this.edges.push(new Edge(this.points[i + 1 - count], this.points[i]));
        } else {
          this.edges.push(new Edge(this.points[i], this.points[i + 1]));
        }
      }

      if (this.points[i + count]) {
        this.edges.push(new Edge(this.points[i], this.points[i + count]));
      }
    }

    for (let i = 0; i < count; i += 1) {
      for (let j = 0; j < count; j += 1) {
        const p0 = i * count + j;
        const p1 = i * count + ((j + 1) % count);
        const p2 = (i + 1) * count + ((j + 1) % count);
        const p3 = (i + 1) * count + j;
        const collor = (i + j) % 2 == 0 ?
        '#a7f3d0aa':
        '#f87171aa';
        if (this.points[p3]) {
          this.polygons.push(
            new Polygon(
              [this.points[p0], 
              this.points[p1], 
              this.points[p2], 
              this.points[p3]], collor));
        }
      }
    }
  }
}
