export class Point {
  constructor(
    public x = 0,
    public y = 0,
    public z = 0,
  ) {}
}

export class Edge {
  constructor(
    public p1 = new Point(),
    public p2 = new Point(),
  ) {}
}

export class Polygon {
  lumen = 1000;
  
  public center = new Point();

  public distance = 0;

  constructor(
    public points: Point[] = [],
    public color = 'rgba(120, 120, 120, 0.35)',
  ) {}
}

export class Figure {
  constructor(
    public points: Point[] = [],
    public edges: Edge[] = [],
    public polygons: Polygon[] = [],
  ) {}
}
