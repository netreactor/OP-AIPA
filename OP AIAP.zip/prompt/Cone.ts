import { Edge, Figure, Point, Polygon } from '../entities';

export class Cone extends Figure {
  constructor(R = 9, height = 18, count = 24) {
    super();
    const peak = new Point(0, 0, height / 2);
    const base: Point[] = [];

    this.points.push(peak);

    for (let i = 0; i < count; i += 1) {
      const alpha = (2 * Math.PI * i) / count;
      const point = new Point(R * Math.cos(alpha), R * Math.sin(alpha), -height / 2);
      base.push(point);
      this.points.push(point);
    }

    for (let i = 0; i < count; i += 1) {
      const next = (i + 1) % count;

      this.edges.push(new Edge(base[i], base[next]));
      this.edges.push(new Edge(peak, base[i]));
      this.polygons.push(new Polygon([peak, base[i], base[next]], '#fbbf24aa'));
    }

    this.polygons.push(new Polygon([...base], '#d1d5dbaa'));
  }
}
