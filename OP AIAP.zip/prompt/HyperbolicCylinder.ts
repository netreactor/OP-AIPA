import { Edge, Figure, Point, Polygon } from '../entities';

export class HyperbolicCylinder extends Figure {
    constructor(count = 20, a = 4, b = 4) {
        super();

        const tMin = -2;
        const tMax = 2;

        const zMin = -10;
        const zMax = 10;

        const tStep = (tMax - tMin) / count;
        const zStep = (zMax - zMin) / count;

        const cols = count + 1;

        // точки
        for (let i = 0; i <= count; i += 1) {
            const t = tMin + i * tStep;

            for (let j = 0; j <= count; j += 1) {
                const z = zMin + j * zStep;

                const x = a * Math.cosh(t);
                const y = b * Math.sinh(t);

                this.points.push(new Point(x, y, z));
            }
        }

        // рёбра
        for (let i = 0; i <= count; i += 1) {
            const rowStart = i * cols;

            for (let j = 0; j < count; j += 1) {

                const current = this.points[rowStart + j];

                this.edges.push(
                    new Edge(current, this.points[rowStart + j + 1])
                );

                if (i < count) {
                    this.edges.push(
                        new Edge(current, this.points[rowStart + j + cols])
                    );
                }
            }
        }

        // полигоны
        for (let i = 0; i < count; i += 1) {

            const rowStart = i * cols;
            const nextRowStart = rowStart + cols;

            for (let j = 0; j < count; j += 1) {

                this.polygons.push(
                    new Polygon([
                        this.points[rowStart + j],
                        this.points[rowStart + j + 1],
                        this.points[nextRowStart + j + 1],
                        this.points[nextRowStart + j]
                    ], '#7209b7')
                );
            }
        }
    }
}