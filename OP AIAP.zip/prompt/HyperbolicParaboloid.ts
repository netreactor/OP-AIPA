import { Edge, Figure, Point, Polygon } from '../entities';

export class HyperbolicParaboloid extends Figure {
    constructor(count = 20, a = 4, b = 4) {
        super();
        const uMin = -10, uMax = 10;
        const vMin = -10, vMax = 10;
        const uStep = (uMax - uMin) / count;
        const vStep = (vMax - vMin) / count;
        const cols = count + 1;

        for (let i = 0; i <= count; i += 1) {
            const u = uMin + i * uStep;
            for (let j = 0; j <= count; j += 1) {
                const v = vMin + j * vStep;
                this.points.push(new Point(u, v, (u * u) / (a * a) - (v * v) / (b * b)));
            }
        }

        for (let i = 0; i <= count; i += 1) {
            const rowStart = i * cols;
            for (let j = 0; j < count; j += 1) {
                const current = this.points[rowStart + j];
                this.edges.push(new Edge(current, this.points[rowStart + j + 1]));
                if (i < count) {
                    this.edges.push(new Edge(current, this.points[rowStart + j + cols]));
                }
            }
        }

        for (let i = 0; i < count; i += 1) {
            const rowStart = i * cols;
            const nextRowStart = rowStart + cols;
            for (let j = 0; j < count; j += 1) {
                
                this.polygons.push(new Polygon([
                    this.points[rowStart + j],
                    this.points[rowStart + j + 1],
                    this.points[nextRowStart + j + 1],
                    this.points[nextRowStart + j]
                ], '#7209b7'));
            }
        }
    }
}