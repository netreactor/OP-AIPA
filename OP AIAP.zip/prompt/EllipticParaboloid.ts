import { Edge, Figure, Point, Polygon } from '../entities';

export class EllipticParaboloid extends Figure {
    constructor(count = 20, a = 4, b = 4) {
        super();

        const xMin = -10;
        const xMax = 10;

        const yMin = -10;
        const yMax = 10;

        const xStep = (xMax - xMin) / count;
        const yStep = (yMax - yMin) / count;

        const cols = count + 1;

        // Точки
        for (let i = 0; i <= count; i += 1) {

            const x = xMin + i * xStep;

            for (let j = 0; j <= count; j += 1) {

                const y = yMin + j * yStep;

                const z =
                    (x * x) / (a * a) +
                    (y * y) / (b * b);

                this.points.push(
                    new Point(x, y, z)
                );
            }
        }

        // Рёбра
        for (let i = 0; i <= count; i += 1) {

            const rowStart = i * cols;

            for (let j = 0; j < count; j += 1) {

                const current =
                    this.points[rowStart + j];

                // вправо
                this.edges.push(
                    new Edge(
                        current,
                        this.points[rowStart + j + 1]
                    )
                );

                // вниз
                if (i < count) {
                    this.edges.push(
                        new Edge(
                            current,
                            this.points[rowStart + j + cols]
                        )
                    );
                }
            }
        }

        // Полигоны
        for (let i = 0; i < count; i += 1) {

            const rowStart = i * cols;
            const nextRowStart = rowStart + cols;

            for (let j = 0; j < count; j += 1) {

                this.polygons.push(
                    new Polygon([
                        this.points[rowStart + j],
                        this.points[rowStart + j + 1],
                        this.points[nextRowStart + j + 1],
                        this.points[nextRowStart + j]
                    ], '#f72585')
                );
            }
        }
    }
}