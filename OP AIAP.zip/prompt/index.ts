import type { Figure } from '../entities';
import { Cone } from './Cone';
import { Cube } from './Cube';
import { Cylinder } from './Cylinder';
import { Ellipsoid } from './Ellipsoid';
import { KleinBottle } from './KleinBottle';
import { Pyramid } from './Pyramid';
import { Sphere } from './Sphere';
import { Torus } from './Torus';
import { HyperbolicCylinder } from './HyperbolicCylinder';
import { ParabolicCylinder } from './ParabolicCylinder';
import { EllipticParaboloid } from './EllipticParaboloid';
import { OneSheetHyperboloid } from './OneSheetHyperboloid';
import { TwoSheetHyperboloid } from './TwoSheetHyperboloid';
import { HyperbolicParaboloid } from './HyperbolicParaboloid';


export type FigureType =
  | 'cube'
  | 'sphere'
  | 'cylinder'
  | 'cone'
  | 'pyramid'
  | 'torus'
  | 'ellipsoid'
  | 'klein'
  | 'HyperbolicCylinder'
  | 'ParabolicCylinder'
  | 'EllipticParaboloid'
  | 'OneSheetHyperboloid'
  | 'TwoSheetHyperboloid'
  | 'HyperbolicParaboloid';

export const FIGURE_OPTIONS: Array<[FigureType, string]> = [
  ['cube', 'Куб'],
  ['sphere', 'Сфера'],
  ['cylinder', 'Цилиндр'],
  ['cone', 'Конус'],
  ['pyramid', 'Пирамида'],
  ['torus', 'Тор'],
  ['ellipsoid', 'Эллипсоид'],
  ['klein', 'Бутылка Клейна'],
  ['HyperbolicCylinder', 'Гипербалоидный Целиндр'],
  ['ParabolicCylinder', 'Параболический Цилиндр'],
  ['EllipticParaboloid', 'Эллиптический Параболоид'],
  ['OneSheetHyperboloid', 'Однополостный Гиперболоид'],
  ['TwoSheetHyperboloid', 'Двуполостный Гиперболоид'],
  ['HyperbolicParaboloid', 'Гиперболический Парабалоид'],
];

export const createFigure = (type: FigureType): Figure => {
  switch (type) {
    case 'sphere':
      return new Sphere();
    case 'cylinder':
      return new Cylinder();
    case 'cone':
      return new Cone();
    case 'pyramid':
      return new Pyramid();
    case 'torus':
      return new Torus();
    case 'ellipsoid':
      return new Ellipsoid();
    case 'klein':
      return new KleinBottle();
    case 'HyperbolicCylinder':
      return new HyperbolicCylinder();
    case 'ParabolicCylinder':
      return new ParabolicCylinder();
    case 'EllipticParaboloid':
      return new EllipticParaboloid();
    case 'OneSheetHyperboloid':
      return new OneSheetHyperboloid();
    case 'TwoSheetHyperboloid':
      return new TwoSheetHyperboloid();
    case 'HyperbolicParaboloid':
      return new HyperbolicParaboloid();
    case 'cube':
    default:
      return new Cube();
  }
};
