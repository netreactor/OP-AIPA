import { Edge, Figure, Point, Polygon } from '../entities';

export class Torus extends Figure {
  constructor(R = 9, r = 3, count = 28, tubeCount = 16) {
    super();

    for (let i = 0; i < count; i += 1) {
      const u = (2 * Math.PI * i) / count;

      for (let j = 0; j < tubeCount; j += 1) {
        const v = (2 * Math.PI * j) / tubeCount;
        const x = (R + r * Math.cos(v)) * Math.cos(u);
        const y = (R + r * Math.cos(v)) * Math.sin(u);
        const z = r * Math.sin(v);

        this.points.push(new Point(x, y, z));
      }
    }

    for (let i = 0; i < count; i += 1) {
      for (let j = 0; j < tubeCount; j += 1) {
        const current = i * tubeCount + j;
        const nextTube = i * tubeCount + ((j + 1) % tubeCount);
        const nextRing = ((i + 1) % count) * tubeCount + j;
        const diagonal = ((i + 1) % count) * tubeCount + ((j + 1) % tubeCount);
    
        this.edges.push(new Edge(this.points[current], this.points[nextTube]));
        this.edges.push(new Edge(this.points[current], this.points[nextRing]));
        
        // 1. Сначала выбираем цвет
        const color = ((i + j) % 2 === 0) ? '#ffffff' : '#000000';
    
        // 2. Затем создаем полигон
        this.polygons.push(new Polygon(
          [
            this.points[current],
            this.points[nextTube],
            this.points[nextRing],
            this.points[diagonal]
          ],
          color
        ));
      }
    }
  }
}