import type { Point, Polygon } from './entities';


export type Viewport3D = {
  left: number;
  bottom: number;
  width: number;
  height: number;
  Camera: Point;
  Focus: Point;
};

export class Math3D {
  constructor(private WIN: Viewport3D) {}

  private LIGHT = {
    x: -1,
    y: -1,
    z: -1,
  };

  xs(point: Point) {
    return (
      ((this.WIN.Camera.z - this.WIN.Focus.z) / (this.WIN.Camera.z - point.z)) * point.x
    );
  }

  ys(point: Point) {
    return (
      ((this.WIN.Camera.z - this.WIN.Focus.z) / (this.WIN.Camera.z - point.z)) * point.y
    );
  }

  multMtoP(M: number[][], P: number[]) {
    const c = [0, 0, 0, 0];

    for (let i = 0; i < 4; i += 1) {
      let s = 0;
      for (let j = 0; j < 4; j += 1) {
        s += M[j][i] * P[j];
      }
      c[i] = s;
    }

    return c;
  }

  zoom(delta: number, point: Point) {
    const c = this.multMtoP(
      [
        [delta, 0, 0, 0],
        [0, delta, 0, 0],
        [0, 0, delta, 0],
        [0, 0, 0, 1],
      ],
      [point.x, point.y, point.z, 1],
    );

    point.x = c[0];
    point.y = c[1];
    point.z = c[2];
  }

  rotateOx(alpha: number, point: Point) {
    const c = this.multMtoP(
      [
        [1, 0, 0, 0],
        [0, Math.cos(alpha), Math.sin(alpha), 0],
        [0, -Math.sin(alpha), Math.cos(alpha), 0],
        [0, 0, 0, 1],
      ],
      [point.x, point.y, point.z, 1],
    );

    point.x = c[0];
    point.y = c[1];
    point.z = c[2];
  }

  rotateOy(alpha: number, point: Point) {
    const c = this.multMtoP(
      [
        [Math.cos(alpha), 0, -Math.sin(alpha), 0],
        [0, 1, 0, 0],
        [Math.sin(alpha), 0, Math.cos(alpha), 0],
        [0, 0, 0, 1],
      ],
      [point.x, point.y, point.z, 1],
    );

    point.x = c[0];
    point.y = c[1];
    point.z = c[2];
  }

  rotateOz(alpha: number, point: Point) {
    const c = this.multMtoP(
      [
        [Math.cos(alpha), Math.sin(alpha), 0, 0],
        [-Math.sin(alpha), Math.cos(alpha), 0, 0],
        [0, 0, 1, 0],
        [0, 0, 0, 1],
      ],
      [point.x, point.y, point.z, 1],
    );

    point.x = c[0];
    point.y = c[1];
    point.z = c[2];
  }

  calcCenter(polygon: Polygon) {
    let x = 0;
    let y = 0;
    let z = 0;

    polygon.points.forEach((point) => {
      x += point.x;
      y += point.y;
      z += point.z;
    });

    polygon.center.x = x / polygon.points.length;
    polygon.center.y = y / polygon.points.length;
    polygon.center.z = z / polygon.points.length;
  }

  calcDistance(polygon: Polygon, endPoint: Point, name: 'distance') {
    polygon[name] = Math.sqrt(
      (endPoint.x - polygon.center.x) ** 2 +
        (endPoint.y - polygon.center.y) ** 2 +
        (endPoint.z - polygon.center.z) ** 2,
    );
  }

  sortByArtist(polygons: Polygon[]) {
    polygons.sort((a, b) => b.distance - a.distance);
  }

  calcLumens(polygon: Polygon) {
    const p1 = polygon.points[0];
    const p2 = polygon.points[1];
    const p3 = polygon.points[2];
  
    // Векторы
    const v1 = {
      x: p2.x - p1.x,
      y: p2.y - p1.y,
      z: p2.z - p1.z,
    };
  
    const v2 = {
      x: p3.x - p1.x,
      y: p3.y - p1.y,
      z: p3.z - p1.z,
    };
  
    // Нормаль
    const normal = {
      x: v1.y * v2.z - v1.z * v2.y,
      y: v1.z * v2.x - v1.x * v2.z,
      z: v1.x * v2.y - v1.y * v2.x,
    };
  
    // Длина нормали
    const length = Math.sqrt(
      normal.x ** 2 +
      normal.y ** 2 +
      normal.z ** 2,
    );
    
    if (length === 0) {
      polygon.lumen = 1;
      return;
    }
  
    // Нормализация
    normal.x /= length;
    normal.y /= length;
    normal.z /= length;
  
    // Скалярное произведение
    const lumen =
      normal.x * this.LIGHT.x +
      normal.y * this.LIGHT.y +
      normal.z * this.LIGHT.z;
  
    // Ограничение
    polygon.lumen = Math.max(0, lumen);
  }
}
