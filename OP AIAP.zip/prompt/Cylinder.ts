import { Edge, Figure, Point, Polygon } from '../entities';

export class Cylinder extends Figure {
  constructor(R = 8, height = 18, count = 24) {
    super();
    const top: Point[] = [];
    const bottom: Point[] = [];

    for (let i = 0; i < count; i += 1) {
      const alpha = (2 * Math.PI * i) / count;
      const x = R * Math.cos(alpha);
      const y = R * Math.sin(alpha);

      top.push(new Point(x, y, height / 2));
      bottom.push(new Point(x, y, -height / 2));
    }

    this.points.push(...top, ...bottom);

    for (let i = 0; i < count; i += 1) {
      const next = (i + 1) % count;

      this.edges.push(new Edge(top[i], top[next]));
      this.edges.push(new Edge(bottom[i], bottom[next]));
      this.edges.push(new Edge(top[i], bottom[i]));
/*       const hue = (i / count) * 360;

      // 2. ПЕРЕВОДИМ УГОЛ В HEX-ЦВЕТ (Магия Math.sin для плавной радуги)
      const r = Math.round(Math.sin(hue * Math.PI / 180 + 0) * 127 + 128).toString(16).padStart(2, '0');
      const g = Math.round(Math.sin(hue * Math.PI / 180 + 2 * Math.PI / 3) * 127 + 128).toString(16).padStart(2, '0');
      const b = Math.round(Math.sin(hue * Math.PI / 180 + 4 * Math.PI / 3) * 127 + 128).toString(16).padStart(2, '0');
      
      const color = `#${r}${g}${b}`; */
      const color =  (i) % 3 == 0 ?
      '#7209b7':
      '#d1d5dbaa';

      this.polygons.push(
        new Polygon([
          top[i], 
          top[next], 
          bottom[next], 
          bottom[i]], 
          color)
        );
    }

    this.polygons.push(new Polygon([...top].reverse(), '#d1d5dbaa'));
    this.polygons.push(new Polygon([...bottom], '#d1d5dbaa'));
  }
}
