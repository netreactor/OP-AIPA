import { Edge, Figure, Point, Polygon } from '../entities';

export class KleinBottle extends Figure {
  constructor(scale = 3, count = 30) {
    super();
    const dU = (2 * Math.PI) / count;
    const dV = (2 * Math.PI) / count;
    const a = 2;

    for (let i = 0; i <= count; i += 1) {
      const u = dU * i;

      for (let j = 0; j <= count; j += 1) {
        const v = dV * j;
        const cosU = Math.cos(u);
        const sinU = Math.sin(u);
        const cosHalfU = Math.cos(u / 2);
        const sinHalfU = Math.sin(u / 2);
        const sinV = Math.sin(v);
        const sin2V = Math.sin(2 * v);

        const r = a + cosHalfU * sinV - sinHalfU * sin2V;
        const x = r * cosU * scale;
        const y = r * sinU * scale;
        const z = (sinHalfU * sinV + cosHalfU * sin2V) * scale;

        this.points.push(new Point(x, y, z));
      }
    }

    const cols = count + 1;

    for (let i = 0; i < count; i += 1) {
      for (let j = 0; j < count; j += 1) {
    
        const idx = i * cols + j;
    
        const p0 = this.points[idx];
        const p1 = this.points[idx + 1];
        const p2 = this.points[idx + cols + 1];
        const p3 = this.points[idx + cols];
    
        // РЁБРА
        this.edges.push(new Edge(p0, p1));
        this.edges.push(new Edge(p0, p3));
    
        // ШАХМАТНЫЙ ЦВЕТ
        const color =
          (i + j) % 2 === 0
            ? '#ffffff'
            : '#000000';
    
        // ПОЛИГОН
        this.polygons.push(new Polygon(
          [
            p0,
            p1,
            p2,
            p3,
          ],
          color
        ));
      }
    }
  }
}
